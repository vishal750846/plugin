<?php

/*

Plugin Name: Crew Apply Form Plugin

Description: Crew Apply Form Plugin. Use Shortcode: [crew-apply-form] in page to display the Crew apply form.

Version: 1.0

Author: DeftSoft

*/

function applyform_install () {
  global $wpdb;
  $upload = wp_upload_dir();
  $upload_dir = $upload['basedir'];
  $upload_dir = $upload_dir . '/crew_photos';
  if (! is_dir($upload_dir)) {
     mkdir( $upload_dir, 0777 );
  }

  $table_name = $wpdb->prefix . "crew_apply_form"; 
  $charset_collate = $wpdb->get_charset_collate();
  $sql = "CREATE TABLE $table_name (
  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `user_profile_url` varchar(255) NOT NULL,
  `profile_url` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `citizenship` varchar(50) NOT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `profession` varchar(255) NOT NULL,
  `profession_other_description` varchar(255) NOT NULL,
  `gear_list` varchar(255) NOT NULL,
  `years_of_experience` varchar(50) NOT NULL,
  `sports_experience` varchar(50) NOT NULL,
  `video1` varchar(255) NOT NULL,
  `video2` varchar(255) NOT NULL,
  `video3` varchar(255) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(255) NOT NULL,
  `image3` varchar(255) NOT NULL,
  `image4` varchar(255) NOT NULL,
  `image5` varchar(255) NOT NULL,
  `image6` varchar(255) NOT NULL,
  `image7` varchar(255) NOT NULL,
  `image8` varchar(255) NOT NULL,
  `image9` varchar(255) NOT NULL,
  `image10` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL
) $charset_collate;";

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
dbDelta( $sql );

$apply_page = array(
  'post_title'    => wp_strip_all_tags( 'Apply Crew Profile' ),
  'post_content'  => '[crew-apply-form]',
  'post_status'   => 'publish',
  'post_author'   => 1,
  'post_type'     => 'page',
);

$view_page = array(
  'post_title'    => wp_strip_all_tags( 'View Crew Profile' ),
  'post_content'  => '[crew-view-profile]',
  'post_status'   => 'publish',
  'post_author'   => 1,
  'post_type'     => 'page',
);

// Insert the post into the database
wp_insert_post( $apply_page );

wp_insert_post( $view_page );

}
register_activation_hook( __FILE__, 'applyform_install');

function rr_scripts() {

  wp_enqueue_script( 'jquery' );

  wp_enqueue_script( 'jquery-ui-datepicker', array( 'jquery' ) );

  wp_register_style('jquery-ui', 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css');
 
  wp_enqueue_style( 'jquery-ui' );

}

add_action( 'wp_enqueue_scripts', 'rr_scripts' );

    function add_my_css_and_my_js_files(){
 
		 wp_enqueue_script( '	', plugins_url('assets/js/jquery.fancybox.js', __FILE__), false, '1.0.0', 'all');

     wp_enqueue_script( 'custom_js', plugins_url('assets/js/custom.js', __FILE__), false, '1.0.0', 'all');

        wp_enqueue_style( 'style', plugins_url('assets/css/style.css', __FILE__), false, '1.0.0', 'all');

		wp_enqueue_style( 'fancybox', plugins_url('assets/css/jquery.fancybox.css', __FILE__), false, '1.0.0', 'all');

    }

    add_action('wp_enqueue_scripts', "add_my_css_and_my_js_files");



class ApplyForm{

  protected static $_instance = null;

  public static function instance() {

    if ( is_null( self::$_instance ) ) {

      self::$_instance = new self();

    }

    return self::$_instance;

  }

  function __construct(){

    $this->load_files();

    $this->load_hooks();

  }

  function load_files(){

	   include_once('includes/admin/class-apply-forms.php');

    include_once('includes/admin/class-apply-settings.php'); 

	 //include_once('includes/frontend/css/jquery-ui.css'); 

	// include_once('includes/frontend/js/jquery-ui.js'); 

  }

  function load_hooks(){

	add_shortcode( 'crew-apply-form', array($this,'apply_form') );

	add_shortcode( 'crew-view-profile', array($this,'view_profile') );

    register_activation_hook ( __FILE__, array($this,'on_activate') );

  }

  function define( $name, $value ) {

    if ( ! defined( $name ) ) {

      define( $name, $value );

    }

  }

  public function plugin_url() {

    return untrailingslashit( plugins_url( '/', VT_PLUGIN_FILE ) );

  }

  public function plugin_path() {

    return untrailingslashit( plugin_dir_path( VT_PLUGIN_FILE ) );

  }

 function my_plugin_scripts() {

      wp_enqueue_script( 'validation', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js', array(), '1.0.0', true );

  }

function view_profile() {

    ob_start();

	  require_once('includes/frontend/view-profile.php');

    return ob_get_clean();

  }

  function apply_form() {

    ob_start();

      require_once('includes/frontend/apply-form.php');

    return ob_get_clean();

  }

}//class end

$ApplyForm = ApplyForm::instance();

?>