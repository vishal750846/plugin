<?php

/**
 * custom_form_table_List_Table class that will display our custom table
 * records in nice table
 */
 
if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}
class form_Table_Example_List_Table extends WP_List_Table
{
    /**
     * [REQUIRED] You must declare constructor and give some basic params
     */
    function __construct()
    {
        global $status, $page;

        parent::__construct(array(
            'singular' => 'crew_form',
            'plural' => 'crew_forms',
        ));
    }

    /**
     * [REQUIRED] this is a default column renderer
     *
     * @param $item - row (key, value array)
     * @param $column_name - string (key)
     * @return HTML
     */
    function column_default($item, $column_name)
    {
        return $item[$column_name];
    }

    /**
     * [OPTIONAL] this is example, how to render specific column
     *
     * method name must be like this: "column_[column_name]"
     *
     * @param $item - row (key, value array)
     * @return HTML
     */

    /**
     * [OPTIONAL] this is example, how to render column with actions,
     * when you hover row "Edit | Delete" links showed
     *
     * @param $item - row (key, value array)
     * @return HTML
     */
    function column_fname($item)
    {
        
        // links going to /admin.php?page=[your_plugin_page][&other_params]
        // notice how we used $_REQUEST['page'], so action will be done on curren page
        // also notice how we use $this->_args['singular'] so in this example it will
        // be something like &person=2

        $actions = array(
            'edit' => sprintf('<a href="?page=crew_forms_apply&id=%s">%s</a>', $item['id'], __('Edit', 'custom_form_table')),
            'delete' => sprintf('<a href="?page=%s&action=delete&id=%s">%s</a>', $_REQUEST['page'], $item['id'], __('Delete', 'custom_form_table')),
        );

        $viewLink = '<a target="_blank" href="'.$item['profile_url'].'">'.$item['fname'].'</a>';
        
        return sprintf('%s %s',
            $viewLink,
            $this->row_actions($actions)
        );
    }
     function column_profile_url($item){
         $actions = array(
        );
         
        $viewLink = '<a target="_blank" href="'.$item['profile_url'].'">'.$item['profile_url'].'</a>';
        
        return sprintf('%s %s',
            $viewLink,
            $this->row_actions($actions)
        );
     }    

    /**
     * [REQUIRED] this is how checkbox column renders
     *
     * @param $item - row (key, value array)
     * @return HTML
     */
    function column_cb($item)
    {
        return sprintf(
            '<input type="checkbox" name="id[]" value="%s" />',
            $item['id']
        );
    }

    /**
     * [REQUIRED] This method return columns to display in table
     * you can skip columns that you do not want to show
     * like content, or description
     *
     * @return array
     */
    function get_columns()
    {
       $columns = array(
            'fname' => __('First Name', 'custom_form_table'),
            'lname' => __('Last Name', 'custom_form_table'),
            'profile_url' => __('User Profile URL', 'custom_form_table'),
            'email' => __('Email', 'custom_form_table'),
            'mobile' => __('Phone', 'custom_form_table'),
            'sports_experience' => __('Sports Experience', 'custom_form_table'),
            'years_of_experience' => __('Years Of Experinece', 'custom_form_table'),
            'profession' => __('Profession', 'custom_form_table'),
            'gender' => __('Gender', 'custom_form_table'),             
        );
        return $columns;
    }

    /**
     * [OPTIONAL] This method return columns that may be used to sort table
     * all strings in array - is column names
     * notice that true on name column means that its default sort
     *
     * @return array
     */
    function get_sortable_columns()
    {
         $sortable_columns = array(
            'fname' => array('fname', true),
            'lname' => array('lname', false),
            'profile_url' => array('user_profile_url', false),
            'email' => array('email', false),
            'mobile' => array('mobile', false),
            'sports_experience' => array('sports_experience', true),
            'years_of_experience' => array('years_of_experience', true),
            'profession' => array('profession', true),
            'gender' => array('gender', false),
        );
        return $sortable_columns;
    }

    /**
     * [OPTIONAL] Return array of bult actions if has any
     *
     * @return array
     */
    function get_bulk_actions()
    {
        $actions = array(
            'delete' => 'Delete'
        );
        return $actions;
    }

    /**
     * [OPTIONAL] This method processes bulk actions
     * it can be outside of class
     * it can not use wp_redirect coz there is output already
     * in this example we are processing delete action
     * message about successful deletion will be shown on page in next part
     */
    function process_bulk_action()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'crew_apply_form'; // do not forget about tables prefix

        if ('delete' === $this->current_action()) {
            $ids = isset($_REQUEST['id']) ? $_REQUEST['id'] : array();
            if (is_array($ids)) $ids = implode(',', $ids);

            if (!empty($ids)) {
                $wpdb->query("DELETE FROM $table_name WHERE id IN($ids)");
            }
        }
    }
    /**
     * [REQUIRED] This is the most important method
     *
     * It will get rows from database and prepare them to be showed in table
     */
     
    function prepare_items($search ='')
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'crew_apply_form'; // do not forget about tables prefix
    
        $per_page = 25; // constant, how much records will be shown per page
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $search_query ='';
        // here we configure table headers, defined in our methods
        $this->_column_headers = array($columns, $hidden, $sortable);

        // [OPTIONAL] process bulk action if any
        $this->process_bulk_action();
        
        if(isset($_GET["form_search"]))
        {
            if($_REQUEST['s']!='') {
                $search_query  = " fname LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or lname LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or mobile LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or gender LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or email LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or city LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or country LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or citizenship LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or profession LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or profession_other_description LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or gear_list LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or years_of_experience LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or sports_experience LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or website LIKE '%".$_REQUEST['s']."%' ";
                $search_query .= " or instagram LIKE '%".$_REQUEST['s']."%' ";

            }
            if ($_REQUEST['profession'] != '' ) {
                 if($_REQUEST['s']!='') {
                $search_query .= " and profession LIKE '%".$_REQUEST['profession']."%' ";
                }
                else{
                $search_query .= " profession LIKE '%".$_REQUEST['profession']."%' ";
                }                
            }
            if ($_REQUEST['years_of_experience'] != '' ) {
                 if($_REQUEST['s']!='' || $_REQUEST['profession'] !='') {
                $search_query .= " and years_of_experience LIKE '%".$_REQUEST['years_of_experience']."%' ";
                }
                else{
                $search_query .= " years_of_experience LIKE '%".$_REQUEST['years_of_experience']."%' ";
                }                
            }
            if ($_REQUEST['location'] != '' ) {
                 if($_REQUEST['s']!='' || $_REQUEST['profession'] !='' || $_REQUEST['years_of_experience']!='') {
                $search_query .= " and country LIKE '%".$_REQUEST['location']."%' ";
                }
                else{
                $search_query .= " country LIKE '%".$_REQUEST['location']."%' ";
                }                
            }
             if ($_REQUEST['gender'] != '' ) {
                 if($_REQUEST['s']!='' || $_REQUEST['profession'] !='' || $_REQUEST['years_of_experience']='' || $_REQUEST['location'] != '') {
                $search_query .= " and gender LIKE '%".$_REQUEST['gender']."%' ";
                }
                else{
                $search_query .= " gender LIKE '%".$_REQUEST['gender']."%' ";
                }                
            }
            if ($_REQUEST['sports_experience'] != '' ) {
                 if($_REQUEST['s']!='' || $_REQUEST['profession'] !='' || $_REQUEST['years_of_experience']='' || $_REQUEST['location'] != '' || $_REQUEST['gender'] != '') {
                $search_query .= " and sports_experience LIKE '%".$_REQUEST['sports_experience']."%' ";
                }
                else{
                $search_query .= " sports_experience LIKE '%".$_REQUEST['sports_experience']."%' ";
                }                
            }
        }
        else{
            $search_query = ' 1=1 ';
        }         
        // will be used in pagination settings
        
        $searchQuery = "SELECT count(*) FROM $table_name where".$search_query;
        $total_items = $wpdb->get_var($searchQuery);
       
        $per_page= 20;
        // prepare query params, as usual current page, order by and order direction
        $paged = isset($_REQUEST['paged']) ? max(0, intval($_REQUEST['paged']) - 1) : 0;
        $paged      = isset($_REQUEST['paged']) ? $_REQUEST['paged'] : 1;
        $orderby = (isset($_REQUEST['orderby']) && in_array($_REQUEST['orderby'], array_keys($this->get_sortable_columns()))) ? $_REQUEST['orderby'] : 'fname';
        
        $order = (isset($_REQUEST['order']) && in_array($_REQUEST['order'], array('asc', 'desc'))) ? $_REQUEST['order'] : 'asc';
        $offset         = ($paged - 1)*$per_page;

            $query =  "SELECT * FROM $table_name where";
            $limit_query  =  "ORDER BY $orderby $order LIMIT ".$per_page." OFFSET ".$offset;
            $fullQuery = $query.$search_query.$limit_query;
            
            // echo $query.$search_query.$limit_query; die();
            $this->items = $wpdb->get_results($fullQuery,ARRAY_A);// return array
    
        $this->set_pagination_args(array(
            'total_items' => $total_items, // total items defined above
            'per_page' => $per_page, // per page constant defined at top of method
            'total_pages' => ceil($total_items / $per_page) // calculate pages count
        ));
    }
}

/**
 * PART 3. Admin page
 * ============================================================================
 *
 * In this part you are going to add admin page for custom table
 *
 * http://codex.wordpress.org/Administration_Menus
 */

/**
 * admin_menu hook implementation, will add pages to list forms and to add new one
 */
function custom_form_table_admin_menu()
{
    add_menu_page(__('Crew Apply form', 'custom_form_table'), __('Crew Apply form', 'custom_form_table'), 'activate_plugins', 'crew_forms', 'custom_form_table_persons_page_handler');
    add_submenu_page('crew_forms', __('Apply form', 'custom_form_table'), __('Crew Apply form', 'custom_form_table'), 'activate_plugins', 'crew_forms', 'custom_form_table_persons_page_handler');
    // add new will be described in next part
    add_submenu_page('crew_forms', __('Add new', 'custom_form_table'), __('Add New', 'custom_form_table'), 'activate_plugins', 'crew_forms_apply', 'custom_form_table_persons_form_page_handler');
    
    
}

add_action('admin_menu', 'custom_form_table_admin_menu');

/**
 * List page handler
 *
 * This function renders our custom table
 * Notice how we display message about successfull deletion
 * Actualy this is very easy, and you can add as many features
 * as you want.
 *
 * Look into /wp-admin/includes/class-wp-*-list-table.php for examples
 */
function custom_form_table_persons_page_handler()
{

    global $wpdb;

    $table = new form_Table_Example_List_Table();
    $table->prepare_items();

    $message = '';
    if ('delete' === $table->current_action()) {
        $message = '<div class="updated below-h2" id="message"><p>' . sprintf(__('Items deleted: %d', 'custom_form_table'), count($_REQUEST['id'])) . '</p></div>';
    }
    ?>
<div class="wrap">

    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
    
    <h2><?php _e('Crew Apply form', 'custom_form_table')?>
        </h2>
    <?php echo $message; ?>
    <style>
   
     .customer_inv input{height:100%; padding: 5px 5px}
     #persons-table .tablenav{display:inline-block;    margin-top: -2px;}
     .customer_inv input[type="submit"]{isplay: inline-block;
    text-decoration: none;
    font-size: 13px;
    line-height: 26px;
    height: 28px;
    margin: 0;
    padding: 0 10px 1px;
    cursor: pointer;
    border-width: 1px;
    border-style: solid;
    -webkit-appearance: none;
    -webkit-border-radius: 3px;
    border-radius: 3px;
    white-space: nowrap; background:transparent; color:#555;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;}
   
    .customer-data-ineer .search-bar {
        width: 100%;
        margin-bottom: 15px;
    }
    .customer-data-ineer .row {
        display: flex;
        flex-wrap: wrap;
        align-items: end;
    }
    .customer-data-ineer .col-lg-4 {
        flex: 0 0 auto;
        width: 32.33333333%;
        max-width: 100%;
        padding: 0 .25rem;
    }
   .customer-data-ineer .form-group {
        display: grid;
        margin-bottom: 10px;
    }
    .customer-data-ineer .cstm-row {
        display: flex;
        flex-wrap: wrap;
        align-items: end;
        justify-content: space-between;
    }
    .cstm-row .col-form-grup {
        flex: 0 0 auto;
        width: 12.1%;
        max-width: 100%;
        padding-right: .25rem;
    }
    .col-form-grup input {
        width: 100%;
    }
    .cstm-rows {
        display: flex;
        flex-wrap: wrap;
        align-items: end;
        justify-content: space-between;
    }
    .col-form-feau input {
        width: 100%;
    }
    .col-form-feau {
        flex: 0 0 auto;
        width: 10.3%;
        max-width: 100%;
        padding-right: .25rem;
    }
    .submit-form-word {
        margin: 0 auto;
        text-align: center;
        padding-bottom: 20px;
    }
    .submit-form-word input[type="submit"] {
        cursor: pointer;
        width: 200px;
        background: #1d2327;
        color: #fff;
        height: 40px;
    }

    .customer-data-ineer .form-group label {
    width: 100%;
}

.customer-data-ineer .form-group select {
    width: 100%;
}
    </style>
    <!-- <form action="<?php //echo $_SERVER['PHP_SELF']; ?>" method="POST"> -->
    
    <!-- </form> -->

    <form name="customerdata" method="get">
        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>"/>
        <div class="customer_inv">
            <?php
                global $wpdb;
                $search_form = $wpdb->get_results("select fname, lname, mobile, email, gender from wp_crew_apply_form where 1 group by fname ",ARRAY_A);// return array
            ?>
   
            <div class="customer-data-ineer">
            <div class="container">
                <input type="text" name="s" placeholder="Search" value="<?php echo $_GET["s"]; ?>" class="search-bar" />
            </div>
            <div class="psnl-details">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="form-group">
                        <label>Profession</label>
                            <select id="profession" name="profession" onchange="yesnoCheck()">
                                <option value="">Select Profession</option>
                                <option value="Director" <?php if($_GET['profession']== 'Director') { echo "selected"; } ?>>Director</option>
                                <option value="Assistant director" <?php if($_GET['profession']== 'Assistant director') { echo "selected"; } ?>>Assistant director</option>
                                <option value="Video grapher" <?php if($_GET['profession']== 'Video grapher') { echo "selected"; } ?>>Video grapher</option>
                                <option value="Photographer" <?php if($_GET['profession']== 'Photographer') { echo "selected"; } ?>>Photographer</option>
                                <option value="Producer" <?php if($_GET['profession']== 'Producer') { echo "selected"; } ?>>Producer</option>
                                <option value="editor" <?php if($_GET['profession']== 'editor') { echo "selected"; } ?>>editor</option>
                                <option value="post production" <?php if($_GET['profession']== 'post production') { echo "selected"; } ?>>post production</option>
                                <option value="sound tech" <?php if($_GET['profession']== 'sound tech') { echo "selected"; } ?>>sound tech</option>
                                <option value="lighting" <?php if($_GET['profession']== 'lighting') { echo "selected"; } ?>>lighting</option>
                                <option value="focus puller" <?php if($_GET['profession']== 'focus puller') { echo "selected"; } ?>>focus puller</option>
                                <option value="gaffer" <?php if($_GET['profession']== 'gaffer') { echo "selected"; } ?>>gaffer</option>
                                <option value="grade" <?php if($_GET['profession']== 'grade') { echo "selected"; } ?>>grade</option>
                                <option value="grips" <?php if($_GET['profession']== 'grips') { echo "selected"; } ?>>grips</option>
                                <option value="rigger" <?php if($_GET['profession']== 'rigger') { echo "selected"; } ?>>rigger</option>
                                <option value="VFX" <?php if($_GET['profession']== 'VFX') { echo "selected"; } ?>>VFX</option>
                                <option value="BTS" <?php if($_GET['profession']== 'BTS') { echo "selected"; } ?>>BTS</option>
                                <option value="wardrobe" <?php if($_GET['profession']== 'wardrobe') { echo "selected"; } ?>>wardrobe</option>
                                <option value="stylist" <?php if($_GET['profession']== 'stylist') { echo "selected"; } ?>>stylist</option>
                                <option value="hair and make-up" <?php if($_GET['profession']== 'hair and make-up') { echo "selected"; } ?>>hair and make-up</option>
                                <option value="runner" <?php if($_GET['profession']== 'runner') { echo "selected"; } ?>>runner</option>
                                <option value="catering" <?php if($_GET['profession']== 'catering') { echo "selected"; } ?>>catering</option>
                                <option value="transport" <?php if($_GET['profession']== 'transport') { echo "selected"; } ?>>transport</option>
                                <option value="other" id="other" <?php if($_GET['profession']== 'other') { echo "selected"; } ?>>Other</option>
                            </select>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <div class="form-group">
                            <label>Years of Experience</label>
                            <select id="years_of_experience" name="years_of_experience">
                                <option value="">Years of Experience</option>
                                <option value="5+" <?php if($_GET['years_of_experience']== '5+') { echo "selected"; } ?>>5+</option>
                                <option value="10+" <?php if($_GET['years_of_experience']== '10+') { echo "selected"; } ?>>10+</option>
                                <option value="15+" <?php if($_GET['years_of_experience']== '15+') { echo "selected"; } ?>>15+</option>
                                <option value="20+" <?php if($_GET['years_of_experience']== '20+') { echo "selected"; } ?>>20+</option>
                            </select>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <div class="form-group">
                                <label>Location</label>
                                <input type="text" value="<?php echo $_GET["location"]; ?>" name="location">
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <div class="form-group">
                                <label>Gender</label>
                                <select class="select-gender" name="gender">
                                    <option for="male" value="male" <?php if($_GET['gender']== 'male') { echo "selected"; } ?>>Male</option>
                                    <option for="female" value="female" <?php if($_GET['gender']== 'female') { echo "selected"; } ?>>Female</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <div class="form-group">
                                <label>Sports Experience</label>
                                <select id="sports_experience" name="sports_experience">
                                    <option value="yes" <?php if($_GET['sports_experience']== 'yes') { echo "selected"; } ?>>Yes</option>
                                    <option value="no" <?php if($_GET['sports_experience']== 'no') { echo "selected"; } ?>>No</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="cstm-rows">                       
            <div class="submit-form-word">
                <input type="submit" name="form_search" value="Search" style="cursor:pointer;" />  
            </div>
        </div>
        </div>
        
        </form>
   
        <div class="persons-table-form">
             <form id="persons-table" method="GET" enctype="multipart/form-data" >
                <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>"/>
                <?php $table->display() ?>
            </form>
        </div>
    <input type="submit" name="export_csv" value="Export CSV" id="csv_download">

</div>
<script type="text/javascript">


jQuery( document ).ready(function() {


jQuery('#csv_download').click(function(e){

e.preventDefault();  

var search_parameter = "<?php echo $_REQUEST['s']; ?>";
var dob = "<?php echo $_REQUEST['dob']; ?>";
var country = "<?php echo $_GET['country']; ?>";
var gender = "<?php echo $_REQUEST['gender']; ?>";
var skin = "<?php echo $_REQUEST['skin']; ?>";
var haircolour = "<?php echo $_REQUEST['haircolour']; ?>";
var eye = "<?php echo $_REQUEST['eye']; ?>";
var hairlength = "<?php echo $_REQUEST['hairlength']; ?>";
var hairtype = "<?php echo $_REQUEST['hairtype']; ?>";
var haveTattoos = "<?php echo $_REQUEST['haveTattoos']; ?>";
var havePiercings = "<?php echo $_REQUEST['havePiercings']; ?>";
var lookalikes = "<?php echo $_REQUEST['lookalikes']; ?>";
var height = "<?php echo $_REQUEST['height']; ?>";
var weight = "<?php echo $_REQUEST['weight']; ?>";
var waist = "<?php echo $_REQUEST['waist']; ?>";
var chest = "<?php echo $_REQUEST['chest']; ?>";
var neck = "<?php echo $_REQUEST['neck']; ?>";
var shoe = "<?php echo $_REQUEST['shoe']; ?>";
var top_size = "<?php echo $_REQUEST['top_size']; ?>";
var bottom_size = "<?php echo $_REQUEST['bottom_size']; ?>";
var inside_leg = "<?php echo $_REQUEST['inside_leg']; ?>";
var primart_sport = "<?php echo $_REQUEST['primart_sport']; ?>";

     jQuery.ajax({ 

             url : '<?php echo admin_url('admin-ajax.php'); ?>', 
             type: 'post', 
             data: {                                  
                    action: 'export_file',
                    search_parameter,
                    dob,
                    country,
                    gender,
                    skin,
                    haircolour,
                    eye,
                    hairlength,
                    hairtype,
                    haveTattoos,
                    havePiercings,
                    lookalikes,
                    height,
                    weight,
                    waist,
                    chest,
                    neck,
                    shoe,
                    top_size,
                    bottom_size,
                    inside_leg,
                    primart_sport,
                    },
                    dataType: 'json',

            
             success: function(data) {
                  console.log(data);

                  // return false;

                  console.log(ConvertToCSV(data));


            function ConvertToCSV(objArray) {
            var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
            var str = '';

            for (var i = 0; i < array.length; i++) {
                var line = '';
                for (var index in array[i]) {
                    if (line != '') line += ','

                    line += array[i][index];
                }

                str += line + '\r\n';
            }

            // return str;
            downloadCSVFile(str , 'crew_apply_form_data');
        }


function downloadCSVFile(csv, filename) {
    var csv_file, download_link;

    csv_file = new Blob([csv], {type: "text/csv"});

    download_link = document.createElement("a");

    download_link.download = filename;

    download_link.href = window.URL.createObjectURL(csv_file);

    download_link.style.display = "none";

    document.body.appendChild(download_link);

    download_link.click();
}                


            }
        });

    });
});


</script>
<?php
}

/**
 * PART 4. Form for adding andor editing row
 * ============================================================================
 *
 * In this part you are going to add admin page for adding andor editing items
 * You cant put all form into this function, but in this example form will
 * be placed into meta box, and if you want you can split your form into
 * as many meta boxes as you want
 *
 * http://codex.wordpress.org/Data_Validation
 * http://codex.wordpress.org/Function_Reference/selected
 */

/**
 * Form page handler checks is there some data posted and tries to save it
 * Also it renders basic wrapper in which we are callin meta box render
 */
function custom_form_table_persons_form_page_handler()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'crew_apply_form'; // do not forget about tables prefix

    
    $message = '';
    $notice = '';
    
    
    $uploaddir = wp_upload_dir();
//echo "<pre>"; print_r($uploaddir); die(); 
//echo "<pre>"; print_r($_FILES['profile_pic']); die();
if(isset($_FILES["profile_pic"]) && !empty($_FILES["profile_pic"])){

if($_FILES['profile_pic']['name']!='') {
    
        $file = $_FILES['profile_pic']['name'];
         $file_size = $_FILES['profile_pic']['size'];
         
        $uploadfile = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

        move_uploaded_file( $_FILES['profile_pic']['tmp_name'], $uploadfile );

            $filename = basename( $uploadfile );

            $filePath = $uploaddir['baseurl'].'/crew_photos/'.$file;

            $wp_filetype = wp_check_filetype(basename($filename), null );
         

} 

}

if($_FILES['image1']['name']!='') {
    
        $file = $_FILES['image1']['name'];
         $file_size = $_FILES['image1']['size'];
         
        $uploadfile_1 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

        move_uploaded_file( $_FILES['image1']['tmp_name'], $uploadfile_1 );

            $filename_1 = basename( $uploadfile_1 );

            $filePath_1 = $uploaddir['baseurl'].'/crew_photos/'.$file;

            $wp_filetype = wp_check_filetype(basename($filePath_1), null );

} 


if($_FILES['image2']['name']!='') {
    
        $file = $_FILES['image2']['name'];
         $file_size = $_FILES['image2']['size'];
         
        $uploadfile_2 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

        move_uploaded_file( $_FILES['image2']['tmp_name'], $uploadfile_2 );

            $filename_2 = basename( $uploadfile_2 );

            $filePath_2 = $uploaddir['baseurl'].'/crew_photos/'.$file;

            $wp_filetype = wp_check_filetype(basename($filePath_2), null );

}

if($_FILES['image3']['name']!='') {
    
        $file = $_FILES['image3']['name'];
         $file_size = $_FILES['image3']['size'];
         
        $uploadfile_3 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

        move_uploaded_file( $_FILES['image3']['tmp_name'], $uploadfile_3 );

            $filename_3 = basename( $uploadfile_3 );

            $filePath_3 = $uploaddir['baseurl'].'/crew_photos/'.$file;

            $wp_filetype = wp_check_filetype(basename($filePath_3), null );

} 

if($_FILES['image4']['name']!='') {
    
        $file = $_FILES['image4']['name'];
         $file_size = $_FILES['image4']['size'];
         
        $uploadfile_4 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

        move_uploaded_file( $_FILES['image4']['tmp_name'], $uploadfile_4 );

            $filename_4 = basename( $uploadfile_4 );

            $filePath_4 = $uploaddir['baseurl'].'/crew_photos/'.$file;

            $wp_filetype = wp_check_filetype(basename($filePath_4), null );

} 

if($_FILES['image5']['name']!='') {
    
        $file = $_FILES['image5']['name'];
         $file_size = $_FILES['image5']['size'];
         
        $uploadfile_5 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

        move_uploaded_file( $_FILES['image5']['tmp_name'], $uploadfile_5 );

            $filename_5 = basename( $uploadfile_5 );

            $filePath_5 = $uploaddir['baseurl'].'/crew_photos/'.$file;

            $wp_filetype = wp_check_filetype(basename($filePath_5), null );

} 


if($_FILES['image6']['name']!='') {
    
    $file = $_FILES['image6']['name'];
     $file_size = $_FILES['image6']['size'];
     
    $uploadfile_6 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

    move_uploaded_file( $_FILES['image6']['tmp_name'], $uploadfile_6 );

        $filename_6 = basename( $uploadfile_6 );

        $filePath_6 = $uploaddir['baseurl'].'/crew_photos/'.$file;

        $wp_filetype = wp_check_filetype(basename($filePath_6), null );

} 


if($_FILES['image7']['name']!='') {
    
    $file = $_FILES['image7']['name'];
     $file_size = $_FILES['image7']['size'];
     
    $uploadfile_7 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

    move_uploaded_file( $_FILES['image7']['tmp_name'], $uploadfile_7 );

        $filename_7 = basename( $uploadfile_7 );

        $filePath_7 = $uploaddir['baseurl'].'/crew_photos/'.$file;

        $wp_filetype = wp_check_filetype(basename($filePath_7), null );

} 


if($_FILES['image8']['name']!='') {
    
    $file = $_FILES['image8']['name'];
     $file_size = $_FILES['image8']['size'];
     
    $uploadfile_8 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

    move_uploaded_file( $_FILES['image8']['tmp_name'], $uploadfile_8 );

        $filename_8 = basename( $uploadfile_8 );

        $filePath_8 = $uploaddir['baseurl'].'/crew_photos/'.$file;

        $wp_filetype = wp_check_filetype(basename($filePath_8), null );

} 


if($_FILES['image9']['name']!='') {
    
    $file = $_FILES['image9']['name'];
     $file_size = $_FILES['image9']['size'];
     
    $uploadfile_9 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

    move_uploaded_file( $_FILES['image9']['tmp_name'], $uploadfile_9 );

        $filename_9 = basename( $uploadfile_9 );

        $filePath_9 = $uploaddir['baseurl'].'/crew_photos/'.$file;

        $wp_filetype = wp_check_filetype(basename($filePath_9), null );

} 


if($_FILES['image10']['name']!='') {
    
    $file = $_FILES['image10']['name'];
     $file_size = $_FILES['image10']['size'];
     
    $uploadfile_10 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );

    move_uploaded_file( $_FILES['image5']['tmp_name'], $uploadfile_10 );

        $filename_10 = basename( $uploadfile_10 );

        $filePath_10 = $uploaddir['baseurl'].'/crew_photos/'.$file;

        $wp_filetype = wp_check_filetype(basename($filePath_10), null );

} 
    // this is default $item which will be used for new records
   $default = array(
        'id' => 0,
        'fname' => '',
        'lname' => '',
        'user_profile_url' => '',
        'profile_url' => '',
        'email' => '',
        'mobile' =>'',
        'gender' =>'',
        'city' =>'',
        'country' =>'',
        'citizenship' =>'',  
        'profession' => '',
        'gear_list' => '',  
        'profession_other_description' => '',
        'years_of_experience' => '',
        'sports_experience' => '',        
        'video1' =>'',
        'video2' =>'',
        'video3' =>'',
        'website' =>'',
        'instagram' =>'',
    );
 
    if(isset($filePath)){
        
        $default['profile_pic'] = $filePath;
    }else{
        $default['profile_pic'] = $wpdb->get_var( "SELECT profile_pic FROM $table_name where id = '".$_GET['id']."'" );
    }
    
    if(isset($filePath_1)){
        
        $default['image1'] = $filePath_1;
    }else{
        $default['image1'] = $wpdb->get_var( "SELECT image1 FROM $table_name where id = '".$_GET['id']."'" );
    }
    
    if(isset($filePath_2)){
        
        $default['image2'] = $filePath_2;
    }else{
        $default['image2'] = $wpdb->get_var( "SELECT image2 FROM $table_name where id = '".$_GET['id']."'" );
    }
    
    if(isset($filePath_3)){
        
        $default['image3'] = $filePath_3;
    }else{
        $default['image3'] = $wpdb->get_var( "SELECT image3 FROM $table_name where id = '".$_GET['id']."'" );
    }
    
    if(isset($filePath_4)){
        
        $default['image4'] = $filePath_4;
    }else{
        $default['image4'] = $wpdb->get_var( "SELECT image4 FROM $table_name where id = '".$_GET['id']."'" );
    }
    
    if(isset($filePath_5)){
        
        $default['image5'] = $filePath_5;
    }else{
        $default['image5'] = $wpdb->get_var( "SELECT image5 FROM $table_name where id = '".$_GET['id']."'" );
    }

    if(isset($filePath_6)){
        
        $default['image6'] = $filePath_6;
    }else{
        $default['image6'] = $wpdb->get_var( "SELECT image6 FROM $table_name where id = '".$_GET['id']."'" );
    }

    if(isset($filePath_7)){
        
        $default['image7'] = $filePath_7;
    }else{
        $default['image7'] = $wpdb->get_var( "SELECT image7 FROM $table_name where id = '".$_GET['id']."'" );
    }

    if(isset($filePath_8)){
        
        $default['image8'] = $filePath_8;
    }else{
        $default['image8'] = $wpdb->get_var( "SELECT image8 FROM $table_name where id = '".$_GET['id']."'" );
    }

    if(isset($filePath_9)){
        
        $default['image9'] = $filePath_9;
    }else{
        $default['image9'] = $wpdb->get_var( "SELECT image9 FROM $table_name where id = '".$_GET['id']."'" );
    }

    if(isset($filePath_10)){
        
        $default['image10'] = $filePath_10;
    }else{
        $default['image10'] = $wpdb->get_var( "SELECT image10 FROM $table_name where id = '".$_GET['id']."'" );
    }
    
   
    // here we are verifying does this request is post back and have correct nonce
    
    if (wp_verify_nonce($_REQUEST['nonce'], basename(__FILE__))) {
        // combine our default item with request params
        $item = shortcode_atts($default, $_REQUEST);
        
        // validate data, and if all ok save item to database
        // if id is zero insert otherwise update
        $item_valid = custom_form_table_validate_person($item);
        
        if ($item_valid === true) {
            
            if ($item['id'] == 0) {
                $result = $wpdb->insert($table_name, $item);
                 
                $item['id'] = $wpdb->insert_id;
                if ($result) {
                    $message = __('Item was successfully saved', 'custom_form_table');
                } else {
                    $notice = __('There was an error while saving item', 'custom_form_table');
                }
            } else {                
                $result = $wpdb->update($table_name, $item, array('id' => $item['id']));
                //echo "<pre>"; print_r($result); die();
                if ($result) {
                    $message = __('Item was successfully updated', 'custom_form_table');
                } else {
                    $notice = __('There was an error while updating item', 'custom_form_table');
                }
                
            }
        } else {
            // if $item_valid not true it contains error message(s)
            $notice = $item_valid;
        }
    }
    else {
        // if this is not post back we load item to edit or give new one to create
        $item = $default;
        if (isset($_REQUEST['id'])) {
            $item = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $_REQUEST['id']), ARRAY_A);
            if (!$item) {
                $item = $default;
                $notice = __('Item not found', 'custom_form_table');
            }
        }
    }

    // here we adding our custom meta box
    add_meta_box('persons_form_meta_box', 'Sports in Motion Application', 'custom_form_table_persons_form_meta_box_handler', 'form', 'normal', 'default');

    ?>
<div class="wrap">
    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
   
    <h2><?php echo esc_attr($item['fname'])?> <?php _e('Crew Apply Form Details', 'custom_form_table')?> 
    <a class="add-new-h2" href="<?php echo get_admin_url(get_current_blog_id(), 'admin.php?page=forms');?>"><?php _e('back to list', 'custom_form_table')?></a>
    </h2>
    <?php if (!empty($notice)): ?>
    <div id="notice" class="error"><p><?php echo $notice ?></p></div>
    <?php endif;?>
    <?php if (!empty($message)): ?>
    <div id="message" class="updated"><p><?php echo $message ?></p></div>
    <?php endif;?>

    <form id="form" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="nonce" value="<?php echo wp_create_nonce(basename(__FILE__))?>"/>
        <?php /* NOTICE: here we storing id to determine will be item added or updated */ ?>
        <input type="hidden" name="id" value="<?php echo $item['id'] ?>"/>

        <div class="metabox-holder" id="poststuff">
            <div id="post-body">
                <div id="post-body-content">
                    <?php /* And here we call our custom meta box */ ?>
                    <?php do_meta_boxes('form', 'normal', $item); ?>
                    <?php if(!empty($_GET['id'])) { ?>
                        <input type="submit" value="<?php _e('Update', 'custom_form_table')?>" id="submit" class="button-primary" name="submit">
                    <?php  } else { ?>
                    <input type="submit" value="<?php _e('Add Form', 'custom_form_table')?>" id="submit" class="button-primary" name="submit">
                    <?php } ?>
                </div>
            </div>
        </div>
    </form>
</div>
<?php
}

/**
 * This function renders our custom meta box
 * $item is row
 *
 * @param $item
 */
function custom_form_table_persons_form_meta_box_handler($item){
?>

<form id="persons-table" method="post" enctype="multipart/form-data" >
<table cellspacing="2" cellpadding="5" style="width: 100%;" class="form-table">
    <tbody>    
          
    <tr class="form-field">
        <th valign="top" scope="row">
            <label for='firstname' >First Name</label>              
        </th>
        <td>
           <input  type="text" name="fname" style="width: 95%" value="<?php echo esc_attr($item['fname'])?>" icon="account_circle" class="" id="input_0" /> 
        </td>
    </tr>           
                
    <tr class="form-field">
        <th valign="top" scope="row">
           <label for='lname' >Last Name</label>
        </th>
        <td>
            <input  type='text' name='lname' style="width: 95%" value="<?php echo esc_attr($item['lname'])?>" icon="account_circle" class="" id="input_0" />            
        </td>
    </tr>           

    <?php if(!$_GET['id']){
        $profile_url_custom = uniqid();
    ?>

    <input type="hidden" name="user_profile_url" value="<?php echo $profile_url_custom; ?>" icon="email">      
    <input type="hidden" name="profile_url" value="<?php echo site_url(); ?>/view-crew-profile/?profileid=<?php echo $profile_url_custom; ?>" >
    <?php }
    else{ ?>

    <input type="hidden" name="user_profile_url" value="<?php echo esc_attr($item['user_profile_url'])?>" icon="email">      
    <input type="hidden" name="profile_url" value="<?php echo site_url(); ?>/view-crew-profile/?profileid=<?php echo esc_attr($item['user_profile_url'])?>" >
    <?php  } ?>
            
    
    <tr class="form-field">
        <th valign="top" scope="row">
            <label for='email' >Email</label>
        </th>
        <td>
            <input  type="email" name="email" value="<?php echo esc_attr($item['email'])?>" icon="email" class="validate" id="email">       
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">
           <label for='mobile' >Mobile number</label>
        </th>
        <td>
            <input  type="tel" name="mobile" value="<?php echo esc_attr($item['mobile'])?>" icon="stay_primary_portrait" class="validate" id="input_5">                    
        </td>
    </tr>
    
        
    <tr class="form-field">
        <th valign="top" scope="row">
          <label for='city' >City</label>
        </th>
        <td>
            <input  type="text" name="city" value="<?php echo esc_attr($item['city'])?>" icon="business" class="" id="input_8">                
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">
          <label for='country' >Country</label>
        </th>
        <td>
            <input  type="text" value="<?php echo esc_attr($item['country'])?>" name="country" class="" id="input_9">                
        </td>
    </tr>    
    
    <tr class="form-field">
        <th valign="top" scope="row">
            <label for='citizenship' >Citizenship</label>
        </th>
        <td>
            <input  type="text" value="<?php echo esc_attr($item['citizenship'])?>" name="citizenship" class="" id="input_11">                
        </td>
    </tr>

    <tr class="form-field">
        <th valign="top" scope="row">
         <label for='gender' >Gender</label>
        </th>
        <td>
            <select  id="gender" name="gender">
                <option value="" >Please Select</option>
                <option <?php if($item['gender']== 'male') { echo "selected"; } ?> value="male">Male</option>
                <option <?php if($item['gender']== 'female') { echo "selected"; } ?> value="female">Female</option>
            </select>                
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">
         <label for='profile_pic' >Profile Pic</label>
        </th>
        <td>
            <img width="100px" height="100px" src="<?php echo esc_attr($item['profile_pic'])?>">
            <input type="file" id="upload" name="profile_pic" value="<?php echo esc_attr($item['profile_pic'])?>">
            <input type="hidden" name="profile_pic1" value="<?php //echo ?>" />
        </td>
    </tr>
    <tr class="form-field">
        <th valign="top" scope="row">
         <label for='profession' >Profession</label>
        </th>
        <td>
<script>
    function yesnoCheck() { 
        if (document.getElementById("other").selected) {
                    document.getElementById("profession_other_description").style.display = "block";
        } else{ 
            document.getElementById("profession_other_description").style.display = "none";
             }
 }        
 </script>
        <select id="profession" name="profession" onchange="yesnoCheck()">
					<option value="">Select Profession</option>
					<option <?php if($item['profession']== 'Director') { echo "selected"; } ?> value="Director">Director</option>
					<option <?php if($item['profession']== 'Assistant director') { echo "selected"; } ?> value="Assistant director">Assistant director</option>
					<option <?php if($item['profession']== 'Video grapher') { echo "selected"; } ?> value="Video grapher">Video grapher</option>
					<option <?php if($item['profession']== 'Photographer') { echo "selected"; } ?> value="Photographer">Photographer</option>
					<option <?php if($item['profession']== 'Producer') { echo "selected"; } ?> value="Producer">Producer</option>
					<option <?php if($item['profession']== 'editor') { echo "selected"; } ?> value="editor">editor</option>
					<option <?php if($item['profession']== 'post production') { echo "selected"; } ?> value="post production">post production</option>
					<option <?php if($item['profession']== 'sound tech') { echo "selected"; } ?> value="sound tech">sound tech</option>
					<option <?php if($item['profession']== 'lighting') { echo "selected"; } ?> value="lighting">lighting</option>
					<option <?php if($item['profession']== 'focus puller') { echo "selected"; } ?> value="focus puller">focus puller</option>
					<option <?php if($item['profession']== 'gaffer') { echo "selected"; } ?> value="gaffer">gaffer</option>
					<option <?php if($item['profession']== 'grade') { echo "selected"; } ?> value="grade">grade</option>
					<option <?php if($item['profession']== 'grips') { echo "selected"; } ?> value="grips">grips</option>
					<option <?php if($item['profession']== 'rigger') { echo "selected"; } ?> value="rigger">rigger</option>
					<option <?php if($item['profession']== 'VFX') { echo "selected"; } ?> value="VFX">VFX</option>
					<option <?php if($item['profession']== 'BTS') { echo "selected"; } ?> value="BTS">BTS</option>
					<option <?php if($item['profession']== 'wardrobe') { echo "selected"; } ?> value="wardrobe">wardrobe</option>
					<option <?php if($item['profession']== 'stylist') { echo "selected"; } ?> value="stylist">stylist</option>
					<option <?php if($item['profession']== 'hair and make-up') { echo "selected"; } ?> value="hair and make-up">hair and make-up</option>
					<option <?php if($item['profession']== 'runner') { echo "selected"; } ?> value="runner">runner</option>
					<option <?php if($item['profession']== 'catering') { echo "selected"; } ?> value="catering">catering</option>
					<option <?php if($item['profession']== 'transport') { echo "selected"; } ?> value="transport">transport</option>
					<option <?php if($item['profession']== 'other') { echo "selected"; } ?> value="other" id="other">Other</option>
				</select>    
                
            <span class="profession_other_description" id="profession_other_description" style="display:none;">
                <label for='profession_other_description' >Please describe your Profession</label>
                <textarea id="profession_other_description" name="profession_other_description" class="materialize-textarea undefined"><?php echo esc_attr($item['profession_other_description'])?></textarea>
            </span>
        </td>
    </tr>

    <tr class="form-field">
        <th valign="top" scope="row">
         <label for='gearlist'>Gear List or Description</label>
        </th>
        <td>
        <textarea id="gear_list" name="gear_list" class="materialize-textarea undefined "><?php echo esc_attr($item['gear_list'])?></textarea>                
        </td>
    </tr>    
    
    <tr class="form-field">
        <th valign="top" scope="row">
        <label for='years_of_experience' >Years of Experience</label>
        </th>
        <td>
            <select id="years_of_experience" name="years_of_experience">
                <option value="">Years of Experience</option>
                <option <?php if($item['years_of_experience']== '5+') { echo "selected"; } ?>  value="5+">5+</option>
                <option <?php if($item['years_of_experience']== '10+') { echo "selected"; } ?>  value="10+">10+</option>
                <option <?php if($item['years_of_experience']== '15+') { echo "selected"; } ?>  value="15+">15+</option>
                <option <?php if($item['years_of_experience']== 'other') { echo "selected"; } ?>  value="20+">20+</option>
            </select>                    
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">
       <label for='sports_experience' >Sports Experience</label>
        </th>
        <td>
            <select id="sports_experience" name="sports_experience">
                <option <?php if($item['sports_experience']== 'yes') { echo "selected"; } ?> value="yes">Yes</option>
                <option <?php if($item['sports_experience']== 'no') { echo "selected"; } ?> value="no">No</option>
            </select>                    
        </td>
    </tr>    
    
    <tr class="form-field">
        <th valign="top" scope="row">        
     <label for='video1' >Video 1</label>
        </th>
        <td>
        <input  type="text" name="video1" icon="video_library" value="<?php echo esc_attr($item['video1'])?>" class="" id="input_26" placeholder="https://">
                                
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">        
     <label for='video1' >Video 2</label>
        </th>
        <td>
        <input  type="text" name="video2" icon="video_library" value="<?php echo esc_attr($item['video2'])?>" class="" id="input_26" placeholder="https://">
                                
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">        
     <label for='video1' >Video 3</label>
        </th>
        <td>
        <input  type="text" name="video3" icon="video_library" value="<?php echo esc_attr($item['video3'])?>" class="" id="input_26" placeholder="https://">                                
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image1' >Image 1</label>
        </th>
        <td>
        <img width="100px;" id="myimg" height="100px;" src="<?php echo esc_attr($item['image1'])?>">
        <span id="img1" Onclick="ConfirmDelete();" >delete</span>
        <input type="file" id="uploadimg1" name="image1" value="<?php echo esc_attr($item['image1'])?>">
        
        </td>
    </tr>
    <?php $image_delete = plugins_url('/apply-form/delete_image.php'); ?>
    <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image1'}, 
            success: function(result){
          
         alert("Image delete successfully");
          jQuery('#myimg').attr("src",'_');
          
        }        
        });   
    }
    </script>
    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image2' >Image 2</label>
        </th>
        <td>
        <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete2() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image2'}, 
            success: function(result){
          
             alert("Image delete successfully");
          jQuery('#myimg2').attr("src",'_');
          
        }        
        });        
    }
    </script>
        <img width="100px;" id="myimg2" height="100px;" src="<?php echo esc_attr($item['image2'])?>">
        <span id="img2" Onclick="ConfirmDelete2();" >delete</span>
        <input type="file" id="upload" name="image2" value="<?php echo esc_attr($item['image2'])?>">
                                    
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image3' >Image 3</label>
        </th>
        <td>
        <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete3() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image3'}, 
            success: function(result){
          
               alert("Image delete successfully");
          jQuery('#myimg3').attr("src",'_');
          
        }        
        });        
    }
    </script>
        <img width="100px;" id="myimg3" height="100px;" src="<?php echo esc_attr($item['image3'])?>">
        <span id="img3" Onclick="ConfirmDelete3();" >delete</span>
        <input type="file" id="upload" name="image3" value="<?php echo esc_attr($item['image3'])?>">
                                    
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image4' >Image 4</label>
        </th>
        <td>
        <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete4() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image4'}, 
            success: function(result){
                alert("Image delete successfully");
          jQuery('#myimg4').attr("src",'_');
          
        }
        
        }); 
        
        
        
    }
    </script>
        <img width="100px;" id="myimg4" height="100px;" src="<?php echo esc_attr($item['image4'])?>">
        <span id="img4" Onclick="ConfirmDelete4();" >delete</span>
        <input type="file" id="upload" name="image4" value="<?php echo esc_attr($item['image4'])?>">
                                    
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image5' >Image 5</label>
        </th>
        <td>
        <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete5() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image5'}, 
            success: function(result){
          alert("Image delete successfully");
          jQuery('#myimg5').attr("src",'_');
          //alert("Here");
          //alert(result);
          
        }        
        });  
    }
    </script>
        <img width="100px;" id="myimg5" height="100px;" src="<?php echo esc_attr($item['image5'])?>">
        <span id="img5" Onclick="ConfirmDelete5();" >delete</span>
            <input type="file" id="upload" name="image5" value="<?php echo esc_attr($item['image5'])?>">                        
        </td>
    </tr>


    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image6' >Image 6</label>
        </th>
        <td>
        <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete6() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image6'}, 
            success: function(result){
          alert("Image delete successfully");
          jQuery('#myimg6').attr("src",'_');
          //alert("Here");
          //alert(result);
          
        }        
        });  
    }
    </script>
        <img width="100px;" id="myimg6" height="100px;" src="<?php echo esc_attr($item['image6'])?>">
        <span id="img6" Onclick="ConfirmDelete6();" >delete</span>
            <input type="file" id="upload" name="image6" value="<?php echo esc_attr($item['image6'])?>">                        
        </td>
    </tr>


    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image7' >Image 7</label>
        </th>
        <td>
        <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete7() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image7'}, 
            success: function(result){
          alert("Image delete successfully");
          jQuery('#myimg7').attr("src",'_');
          //alert("Here");
          //alert(result);
          
        }        
        });  
    }
    </script>
        <img width="100px;" id="myimg7" height="100px;" src="<?php echo esc_attr($item['image7'])?>">
        <span id="img7" Onclick="ConfirmDelete7();" >delete</span>
            <input type="file" id="upload" name="image7" value="<?php echo esc_attr($item['image7'])?>">                        
        </td>
    </tr>


    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image8' >Image 8</label>
        </th>
        <td>
        <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete8() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image8'}, 
            success: function(result){
          alert("Image delete successfully");
          jQuery('#myimg8').attr("src",'_');
          //alert("Here");
          //alert(result);
          
        }        
        });  
    }
    </script>
        <img width="100px;" id="myimg8" height="100px;" src="<?php echo esc_attr($item['image8'])?>">
        <span id="img8" Onclick="ConfirmDelete8();" >delete</span>
            <input type="file" id="upload" name="image8" value="<?php echo esc_attr($item['image8'])?>">                        
        </td>
    </tr>


    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image9' >Image 9</label>
        </th>
        <td>
        <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete9() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image9'}, 
            success: function(result){
          alert("Image delete successfully");
          jQuery('#myimg9').attr("src",'_');
          //alert("Here");
          //alert(result);
          
        }        
        });  
    }
    </script>
        <img width="100px;" id="myimg9" height="100px;" src="<?php echo esc_attr($item['image9'])?>">
        <span id="img9" Onclick="ConfirmDelete9();" >delete</span>
            <input type="file" id="upload" name="image9" value="<?php echo esc_attr($item['image9'])?>">                        
        </td>
    </tr>


    <tr class="form-field">
        <th valign="top" scope="row">
        
    <label for='image10' >Image 10</label>
        </th>
        <td>
        <script>
    
    var imID = "<?php echo $item['id']; ?>";
    function ConfirmDelete10() {
        
        jQuery.ajax({url: "<?php echo $image_delete; ?>",type: "POST",
        dataType: "text",
        data:{"id" : imID,"imageflag" : 'image10'}, 
            success: function(result){
          alert("Image delete successfully");
          jQuery('#myimg10').attr("src",'_');          
        }        
        });  
    }
    </script>
        <img width="100px;" id="myimg5" height="100px;" src="<?php echo esc_attr($item['image10'])?>">
        <span id="img10" Onclick="ConfirmDelete10();" >delete</span>
            <input type="file" id="upload" name="image10" value="<?php echo esc_attr($item['image10'])?>">                        
        </td>
    </tr>
    

    <tr class="form-field">
        <th valign="top" scope="row">        
            <label for='website' >Website</label>
        </th>
        <td>
        <input type="text" name="website" value="<?php echo esc_attr($item['website'])?>" class="" id="input_29" placeholder="Website Url">                                    
        </td>
    </tr>
    
    <tr class="form-field">
        <th valign="top" scope="row">        
            <label for='instagram' >Instagram</label>
        </th>
        <td>
            <input  type="text" name="instagram" value="<?php echo esc_attr($item['instagram'])?>" class="" id="input_29" placeholder="Instagram Url">                                    
        </td>
    </tr>
    
        </tbody>   
    </table>              
</form>

<?php
}
function custom_form_table_validate_person($item)
{
    $messages = array();
 
    if (empty($item['fname'])) $messages[] = __('First Name is required', 'custom_form_table');
    if (empty($item['lname'])) $messages[] = __('Last Name is required', 'custom_form_table'); 
    if (empty($item['email'])) $messages[] = __('Email is required', 'custom_form_table');
    if (empty($item['mobile'])) $messages[] = __('Mobile is required', 'custom_form_table');
    if (empty($item['gender'])) $messages[] = __('Gender is required', 'custom_form_table');
    if (empty($item['city'])) $messages[] = __('City is required', 'custom_form_table');
    if (empty($item['country'])) $messages[] = __('Country is required', 'custom_form_table');
    if (empty($item['citizenship'])) $messages[] = __('Citizenship is required', 'custom_form_table');

    if (empty($item['profession'])) $messages[] = __('Profession is required', 'custom_form_table');
    if (empty($item['gear_list'])) $messages[] = __('Gearlist or description is required', 'custom_form_table');
    if (empty($item['years_of_experience'])) $messages[] = __('years_of_experience is required', 'custom_form_table');
    if (empty($item['sports_experience'])) $messages[] = __('sports_experience is required', 'custom_form_table');

    if (empty($item['video1'])) $messages[] = __('Video is required', 'custom_form_table');
    if (empty($item['video2'])) $messages[] = __('Video is required', 'custom_form_table');
    if (empty($item['video3'])) $messages[] = __('Video is required', 'custom_form_table');

    if (empty($item['website'])) $messages[] = __('website_url is required', 'custom_form_table');
    if (empty($item['instagram'])) $messages[] = __('instagram_url is required', 'custom_form_table');

    if (empty($messages)) return true;
    return implode('<br />', $messages);
}


// *********************************************************************
//                          CSV EXPORT CODE
// *********************************************************************


add_action('wp_ajax_export_file', 'export_file');
add_action( 'wp_ajax_nopriv_export_file', 'export_file' ); 

    function export_file() {

        $export_essential = true;

        global $wpdb;
        $search_parameter = $_POST['search_parameter'];
        $dob = $_POST['dob'];
        $country = $_POST['country'];
        $gender = $_POST['gender'];
        $skin = $_POST['skin'];
        $haircolour = $_POST['haircolour'];
        $eye = $_POST['eye'];
        $hairlength = $_POST['hairlength'];
        $hairtype = $_POST['hairtype'];
        $haveTattoos = $_POST['haveTattoos'];
        $havePiercings = $_POST['havePiercings'];
        $lookalikes = $_POST['lookalikes'];
        $height = $_POST['height'];
        $weight = $_POST['weight'];
        $waist = $_POST['waist'];
        $chest = $_POST['chest'];
        $neck = $_POST['neck'];
        $shoe = $_POST['shoe'];
        $top_size = $_POST['top_size'];
        $bottom_size = $_POST['bottom_size'];
        $inside_leg = $_POST['inside_leg'];
        $primart_sport = $_POST['primart_sport'];

if ($export_essential) {

        if($search_parameter!='') {
            $search_query  = "where fname LIKE '%".$search_parameter."%' ";
            $search_query .= " or lname LIKE '%".$search_parameter."%' ";
            $search_query .= " or mobile LIKE '%".$search_parameter."%' ";
            $search_query .= " or gender LIKE '%".$search_parameter."%' ";
            $search_query .= " or email LIKE '%".$search_parameter."%' ";
            $search_query .= " or dob LIKE '%".$search_parameter."%' ";
            $search_query .= " or city LIKE '%".$search_parameter."%' ";
            $search_query .= " or country LIKE '%".$search_parameter."%' ";
            $search_query .= " or citizenship LIKE '%".$search_parameter."%' ";
            $search_query .= " or skin LIKE '%".$search_parameter."%' ";
            $search_query .= " or eye LIKE '%".$search_parameter."%' ";
            $search_query .= " or haircolour LIKE '%".$search_parameter."%' ";
            $search_query .= " or hairlength LIKE '%".$search_parameter."%' ";
            $search_query .= " or hairtype LIKE '%".$search_parameter."%' ";
            $search_query .= " or lookalikes LIKE '%".$search_parameter."%' ";
            $search_query .= " or haveTattoos LIKE '%".$search_parameter."%' ";
            $search_query .= " or tattoos LIKE '%".$search_parameter."%' ";
            $search_query .= " or havePiercings LIKE '%".$search_parameter."%' ";
            $search_query .= " or piercings LIKE '%".$search_parameter."%' ";
            $search_query .= " or height LIKE '%".$search_parameter."%' ";
            $search_query .= " or weight LIKE '%".$search_parameter."%' ";
            $search_query .= " or waist LIKE '%".$search_parameter."%' ";
            $search_query .= " or chest LIKE '%".$search_parameter."%' ";
            $search_query .= " or neck LIKE '%".$search_parameter."%' ";
            $search_query .= " or shoe LIKE '%".$search_parameter."%' ";
            $search_query .= " or skills LIKE '%".$search_parameter."%' ";
            $search_query .= " or experience LIKE '%".$search_parameter."%' ";
            $search_query .= " or top_size LIKE '%".$search_parameter."%' ";
            $search_query .= " or bottom_size LIKE '%".$search_parameter."%' ";
            $search_query .= " or inside_leg LIKE '%".$search_parameter."%' ";

        }

            if ($dob != '' ) {
                 if($search_parameter !='') {
                $search_query .= " and dob LIKE '%".$dob."%' ";
                }
                else{
                $search_query = " where dob LIKE '%".$dob."%' ";
                }                
            }
            if ($country != '' ) {
                 if($search_parameter != '' || $dob !='') {
                $search_query .= " and country LIKE '%".$country."%' ";
                }
                else{
                $search_query = " where country LIKE '%".$country."%' ";
                }                
            }
            if ($gender != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '') {
                $search_query = " and gender LIKE '%".$gender."%' ";
                }
                else{
                $search_query = " where gender LIKE '%".$gender."%' ";
                }                
            }
             if ($skin != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '') {
                $search_query .= " and skin LIKE '%".$skin."%' ";
                }
                else{
                $search_query = " where skin LIKE '%".$skin."%' ";
                }                
            }
            if ($haircolour != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '') {
                $search_query .= " and haircolour LIKE '%".$haircolour."%' ";
                }
                else{
                $search_query = " where haircolour LIKE '%".$haircolour."%' ";
                }                
            }
            if ($eye != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '') {
                $search_query .= " and eye LIKE '%".$eye."%' ";
                }
                else{
                $search_query = " where eye LIKE '%".$eye."%' ";
                }                
            }
            if ($hairlength != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' ) {
                $search_query .= " and hairlength LIKE '%".$hairlength."%' ";
                }
                else{
                $search_query = " where hairlength LIKE '%".$hairlength."%' ";
                }                
            }
            if ($hairtype != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' ) {
                $search_query .= " and hairtype LIKE '%".$hairtype."%' ";
                }
                else{
                $search_query = " where hairtype LIKE '%".$hairtype."%' ";
                }                
            }
            if ($haveTattoos != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' ) {
                $search_query .= " and haveTattoos LIKE '%".$haveTattoos."%' ";
                }
                else{
                $search_query = " where haveTattoos LIKE '%".$haveTattoos."%' ";
                }                
            }
            if ($havePiercings != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' ) {
                $search_query .= " and havePiercings LIKE '%".$havePiercings."%' ";
                }
                else{
                $search_query = " where havePiercings LIKE '%".$havePiercings."%' ";
                }                
            }
            if ($lookalikes != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' ) {
                $search_query .= " and lookalikes LIKE '%".$lookalikes."%' ";
                }
                else{
                $search_query = " where lookalikes LIKE '%".$lookalikes."%' ";
                }                
            }
            if ($height != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != ''  ) {
                $search_query .= " and height LIKE '%".$height."%' ";
                }
                else{
                $search_query = " where height LIKE '%".$height."%' ";
                }                
            }
            if ($weight != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != '' || $height != '' ) {
                $search_query .= " and weight LIKE '%".$weight."%' ";
                }
                else{
                $search_query = " where weight LIKE '%".$weight."%' ";
                }                
            }
            if ($waist != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != '' || $height != '' || $weight != '' ) {
                $search_query .= " and waist LIKE '%".$waist."%' ";
                }
                else{
                $search_query = " where waist LIKE '%".$waist."%' ";
                }                
            }
            if ($chest != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != '' || $height != '' || $weight != '' || $waist != '' ) {
                $search_query .= " and chest LIKE '%".$chest."%' ";
                }
                else{
                $search_query = " where chest LIKE '%".$chest."%' ";
                }                
            }
            if ($neck != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != '' || $height != '' || $weight != '' || $waist != '' || $chest != '' ) {
                $search_query .= " and neck LIKE '%".$neck."%' ";
                }
                else{
                $search_query = " where neck LIKE '%".$neck."%' ";
                }                
            }
            if ($shoe != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != '' || $height != '' || $weight != '' || $waist != '' || $chest != '' || $neck != '' ) {
                $search_query .= " and shoe LIKE '%".$shoe."%' ";
                }
                else{
                $search_query = " where shoe LIKE '%".$shoe."%' ";
                }                
            }
            if ($top_size != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != '' || $height != '' || $weight != '' || $waist != '' || $chest != '' || $neck != '' || $shoe != '' ) {
                $search_query .= " and top_size LIKE '%".$top_size."%' ";
                }
                else{
                $search_query = " where top_size LIKE '%".$top_size."%' ";
                }                
            }
            if ($bottom_size != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != '' || $height != '' || $weight != '' || $waist != '' || $chest != '' || $neck != '' || $shoe != '' || $top_size != ''  ) {
                $search_query .= " and bottom_size LIKE '%".$bottom_size."%' ";
                }
                else{
                $search_query = " where bottom_size LIKE '%".$bottom_size."%' ";
                }                
            }
            if ($inside_leg != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != '' || $height != '' || $weight != '' || $waist != '' || $chest != '' || $neck != '' || $shoe != '' || $top_size != '' || $bottom_size != ''  ) {
                $search_query .= " and inside_leg LIKE '%".$inside_leg."%' ";
                }
                else{
                $search_query = " where inside_leg LIKE '%".$inside_leg."%' ";
                }                
            }
            if ($primart_sport != '' ) {
                 if($search_parameter != '' || $dob !='' || $country != '' || $gender != '' || $skin != '' || $haircolour != '' || $eye != '' || $hairlength != '' || $hairtype != '' || $haveTattoos != '' || $havePiercings != '' || $lookalikes != '' || $height != '' || $weight != '' || $waist != '' || $chest != '' || $neck != '' || $shoe != '' || $top_size != '' || $bottom_size != '' || $inside_leg != ''  ) {
                $search_query .= " and skills LIKE '%".$primart_sport."%' ";
                }
                else{
                $search_query = " where skills LIKE '%".$primart_sport."%' ";
                }                
            }
        }
        else{
            $search_query = ' 1=1 ';
        }
        
        $TableName= 'wp_crew_apply_form'; // Define Your Table Name
        
        $query =  "SELECT * FROM $TableName";
        $result = $wpdb->get_results($query.$search_query);

        echo json_encode($result);
        wp_die();

}

// *********************************************************************
//                          CSV EXPORT CODE
// *********************************************************************
?>