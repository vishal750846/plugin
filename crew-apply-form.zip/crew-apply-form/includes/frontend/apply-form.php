 <script src='https://www.google.com/recaptcha/api.js' async defer></script>
	<div class="logo" style="text-align:center">
		<a href="javascript:;">
			<img src="https://sportandmotion.com/wp-content/uploads/2022/10/SM-Logo-copy.jpg" alt="logo1">
		</a>
	</div>
<?php
  global $current_user,$wpdb;
$uploaddir = wp_upload_dir();

if(isset($_POST['applyform'])) {
	//  if(!isset($_POST['g-recaptcha-response'])){
    //       $captcha=$_POST['g-recaptcha-response'];
    //       exit;
	// }

	$user_profile_url =  uniqid();
	$query = new WP_Query( 'page_id=558' ); 
	while ($query -> have_posts()) : $query -> the_post();	
	$content= get_the_content();


	endwhile;
	//echo $content;
	 	
	$content = str_replace("{{fname}}",$_REQUEST['fname'],$content);
    $content = str_replace("{{lname}}",$_REQUEST['lname'],$content);	
	$content = str_replace("{{user_profile_url}}",$user_profile_url,$content);
	
   $admin_email = get_option( 'admin_email' );

	$headers = "MIME-Version: 1.0" . "\r\n";
	$subject = "Sport And Motion Application Form";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= 'From: <noreply@sportandmotion.com>' . "\r\n";

	mail($admin_email,$subject,$content,$headers);


    $email_for_userEmail = $_POST["email"]; 

    $content_for_userEmail = 'Hi '.$_POST["fname"].' '.$_POST["lname"].' ,<br><br>';
    $content_for_userEmail .= "Hope you're well.<br><br>";
    $content_for_userEmail .= "Thank you for registering with us at Sport & Motion - it's great to have you on board with us! <br><br>";
    $content_for_userEmail .= "<b>Please find below a copy of your profile : </b>(<a href='https://sportandmotion.com/view-crew-profile/?profileid=".$user_profile_url."' target='_blank'>https://sportandmotion.com/view-crew-profile/?profileid=".$user_profile_url.")</a><br><br>";
    $content_for_userEmail .= "We are a Sports Consultancy company providing services in the following areas; Talent, Choreography, Events, Production & Film. We are based in the City of London, offering our services across all industries globally from small to large scale.<br><br>";
    $content_for_userEmail .= "In addition to that we work closely with our clients regularly supplying Multi Sports Talent/ Athletes ranging from Footballers to Body Doubles to Gymnasts, Rugby Players, Cricketers, Tennis, Golf etc. (the list of Sport is endless). In regards to Production & Film, we also provide our clients with a built up pre/post production team or individual varying from roles such as; Photographer, Videographer, DOP, Creatives and many more. The type of projects we typically would get you involved in are photoshoots, social media content, TV commercials, sports events etc. <br><br>";

     $content_for_userEmail .= "As soon as something pops up, we shall give you a shout - we look forward to working with you! <br><br>";

     $content_for_userEmail .= "<b>PS. This is a non-exclusive agreement; rest assured there are no strict contracts or ties with us. For peace of mind our team will shortly send you a copy of terms & conditions. Also to clarify – your profile above won’t be shared with anyone until we have your consent to, therefore if any work comes in we’d discuss with you first and go from there!</b><br><br>";

     $content_for_userEmail .= "If you haven't already done so, please follow us on <a href='https://www.instagram.com/sportandmotion/' target='_blank'>Instagram</a> and <a href='https://www.linkedin.com/company/sportandmotion/' target='_blank'>LinkedIn</a> – lets stay connected. Any questions in the meantime, feel free to reach out - happy to help anytime.<br><br>";
     $content_for_userEmail .= "All the best,<br><br>";
     $content_for_userEmail .= "Sport & Motion Team<br><br>";
     $content_for_userEmail .= '<div dir=ltr><table style=direction:ltr;border-collapse:collapse;><tr><td style=font-size:0;height:12px;line-height:0;></td></tr><tr><td><table cellpadding=0 cellspacing=0 style=border-collapse:collapse;font-family:Arial;line-height:1.15;color:#000;><tr><td style="vertical-align:top;padding:.01px 14px 0.01px 1px;width:65px;text-align:center;"><img src=https://cdn.gifo.wisestamp.com/im/sh/dS9WUTc0azd2a2w5eS8xNjY1NDA2MTcwNTYxLnBuZyNsb2dv/circle.png#logo height=auto width=65 style=width:65px;vertical-align:middle;border-radius:50%;height:auto;></td><td valign=top style="padding:.01px 0.01px 0.01px 14px;vertical-align:top;"><table cellpadding=0 cellspacing=0 style=border-collapse:collapse;><tr><td style=line-height:1.2;padding:.01px;font-family:Arial;><span style=text-transform:initial;font-weight:bold;color:#191C2B;letter-spacing:0;line-height:1.2;font-size:18px;> Sport & Motion Team </span><br /><span style=text-transform:initial;font-weight:bold;color:#646464;line-height:1.2;font-size:14px;> Sport & Motion </span></td></tr><tr><td><table cellpadding=0 cellspacing=0 style=border-collapse:collapse;><tr><td nowrap width=201 style=padding-top:14px;white-space:nowrap;width:201px;font-family:Arial;><p style=margin:.1px;line-height:1;><span style=font-size:12px;color:#212121;white-space:nowrap;><img src=https://cdn.gifo.wisestamp.com/s/rfw1/191C2B/26/trans.png style=vertical-align:-2px;line-height:1.2;width:13px; width=13><!--[if mso]><span>&nbsp;</span><![endif]--><a href=http://www.sportandmotion.com target=_blank style=font-family:Arial;text-decoration:unset;><span style=line-height:1.2;font-family:Arial;color-scheme:only;color:#212121;white-space:nowrap;> www.sportandmotion.com </span></a></span></p></td></tr><tr><td nowrap width=259 style=padding-top:8px;white-space:nowrap;width:259px;font-family:Arial;><p style=margin:.1px;line-height:1;><span style=font-size:12px;color:#212121;white-space:nowrap;><img src=https://cdn.gifo.wisestamp.com/s/rfem1/191C2B/26/trans.png style=vertical-align:-2px;line-height:1.2;width:13px; width=13><!--[if mso]><span>&nbsp;</span><![endif]--><a href=mailto:production@sportandmotion.com target=_blank style=font-family:Arial;text-decoration:unset;><span style=line-height:1.2;font-family:Arial;color-scheme:only;color:#212121;white-space:nowrap;> production@sportandmotion.com </span></a></span></p></td></tr></table></td></tr><tr><td style="padding:14px 0.01px 0.01px 0.01px;"><table border=0 cellpadding=0 cellspacing=0><tr><td align=left style=padding-right:6px;text-align:center;padding-top:0;><a href=https://www.instagram.com/sportandmotion/ target=_blank><img width=24 height=24 src=https://cdn.gifo.wisestamp.com/s/inst/E4405F/48/circle/background.png style=float:left;border:none; border=0></a></td><td align=left style=padding-right:6px;text-align:center;padding-top:0;><a href=https://www.linkedin.com/company/sportandmotion/ target=_blank><img width=24 height=24 src=https://cdn.gifo.wisestamp.com/s/ld/0077b5/48/circle/background.png style=float:left;border:none; border=0></a></td></tr></table></td></tr></table></td></tr></table><table cellpadding=0 cellspacing=0 border=0 width=100%><tr><td height=16px style=line-height:0;height:16px;></td></tr></table><table cellpadding=0 cellspacing=0 border=0 style=max-width:600px;width:100%;><tr><td style=line-height:0;><table cellpadding=0 cellspacing=0 width=100% style="width:100%;padding-right:8px;color:gray;border-top:1px solid gray;font-size:13px;line-height:normal;"><tr><td><p style="color:#808080;text-align:left;font-size:10px;margin:0;line-height:120%;padding-top:10px;font-family:Arial "> IMPORTANT: The contents of this email and any attachments are confidential. They are intended for the named recipient(s) only. If you have received this email by mistake, please notify the sender immediately and do not disclose the contents to anyone or make copies thereof. </p></td></tr></table><table cellpadding=0 cellspacing=0 border=0 width=100%><tr><td style=line-height:0;height:16px;max-width:600px;></td></tr></table><table cellpadding=0 cellspacing=0 style=padding-right:8px;line-height:normal;><tr><td style="font-family:Arial;padding:1px 8px 4px 2px;"><a href=https://www.instagram.com/sportandmotion/ target=_blank style=text-decoration:none;line-height:1.1;font-size:12px;font-family:Arial;color:#9F9F9F;font-weight:bold;> @sportandmotion </a></td></tr><tr><td><table cellpadding=0 cellspacing=0><tr><td style=padding:0;width:48px;padding-right:15px; width=48><a style=text-decoration:none; href=https://www.instagram.com/sportandmotion/ target=_blank><img width=48 style=display:block;width:48px; src=https://d36urhup7zbd7q.cloudfront.net/u/VQ74k7vkl9y/1665408747307.jpeg alt="Gallery Image"></a></td><td style=padding:0;width:48px;padding-right:15px; width=48><a style=text-decoration:none; href=https://www.instagram.com/sportandmotion/ target=_blank><img width=48 style=display:block;width:48px; src=https://d36urhup7zbd7q.cloudfront.net/u/VQ74k7vkl9y/1665408757320.jpeg alt="Gallery Image"></a></td><td style=padding:0;width:48px;padding-right:15px; width=48><a style=text-decoration:none; href=https://www.instagram.com/sportandmotion/ target=_blank><img width=48 style=display:block;width:48px; src=https://d36urhup7zbd7q.cloudfront.net/u/VQ74k7vkl9y/1665408787882.jpeg alt="Gallery Image"></a></td><td style=padding:0;width:48px;padding-right:15px; width=48><a style=text-decoration:none; href=https://www.instagram.com/sportandmotion/ target=_blank><img width=48 style=display:block;width:48px; src=https://d36urhup7zbd7q.cloudfront.net/u/VQ74k7vkl9y/1670974612990.jpeg alt="Gallery Image"></a></td><td style=padding:0;width:48px;padding-right:15px; width=48><a style=text-decoration:none; href=https://www.instagram.com/sportandmotion/ target=_blank><img width=48 style=display:block;width:48px; src=https://d36urhup7zbd7q.cloudfront.net/u/VQ74k7vkl9y/1670974700478.jpeg alt="Gallery Image"></a></td><td style=padding:0;width:48px;padding-right:15px; width=48><a style=text-decoration:none; href=https://www.instagram.com/sportandmotion/ target=_blank><img width=48 style=display:block;width:48px; src=https://d36urhup7zbd7q.cloudfront.net/u/VQ74k7vkl9y/1670974876002.jpeg alt="Gallery Image"></a></td></tr></table></td></tr></table><table cellpadding=0 cellspacing=0 border=0 width=100%><tr><td style=line-height:0;height:16px;max-width:600px;></td></tr></table></td></td></table></td></tr><tr><td style="font-family:"ws-id None";font-size:.01px;line-height:0;">&nbsp;</td></tr></table></div><img src=https://tracy.srv.wisestamp.com/px/4684082339512320.png?eid=5018832023453696 alt=>';

    $headerss = "MIME-Version: 1.0" . "\r\n";
    $headerss .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headerss .= 'From: <info@sportandmotion.com>' . "\r\n";

    mail($email_for_userEmail,$subject,$content_for_userEmail,$headerss);
	
	?>
	<span class="title">Thanks for sending us your application, you'll shortly receive a confirmation email. We'll be in touch with you as soon as we've reviewed it. Please check your Junk mail incase it lands in there! If you still receive nothing, please email: info@sportandmotion.com</span>
	<div class="centerAll">All done! You can close this window.</div>
	<?php 
	//print_r($_FILES);die();
		if($_FILES['profile_pic']['name']!='') {
		$file = $_FILES['profile_pic']['name'];
		$file_size = $_FILES['profile_pic']['size'];		 
		$uploadfile = $uploaddir['basedir'] . '/crew_photos/' . basename( $file );
		move_uploaded_file( $_FILES['profile_pic']['tmp_name'], $uploadfile );
		$filename = basename( $uploadfile );
		$filePath = $uploaddir['baseurl'].'/crew_photos/'.$file;
		$wp_filetype = wp_check_filetype(basename($filename), null );
		}

		if($_FILES['image1']['name']!='') {	
		$file_1 = $_FILES['image1']['name'];
		$uploadfile_1 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_1 );
		move_uploaded_file( $_FILES['image1']['tmp_name'], $uploadfile_1);
		$filename_1 = basename( $uploadfile_1 );
		$filePath_1 = $uploaddir['baseurl'].'/crew_photos/'.$file_1;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filename_1), null );
		}	

		if($_FILES['image2']['name']!='') {	
		$file_2 = $_FILES['image2']['name'];
		$uploadfile_2 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_2 );
		move_uploaded_file( $_FILES['image2']['tmp_name'], $uploadfile_2);
		$filename_2 = basename( $uploadfile_2 );
		$filePath_2 = $uploaddir['baseurl'].'/crew_photos/'.$file_2;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filePath_2), null );
		}

		if($_FILES['image3']['name']!='') {	
		$file_3 = $_FILES['image3']['name'];
		$uploadfile_3 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_3 );
		move_uploaded_file( $_FILES['image3']['tmp_name'], $uploadfile_3);
		$filename_3 = basename( $uploadfile_3 );
		$filePath_3 = $uploaddir['baseurl'].'/crew_photos/'.$file_3;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filePath_3), null );
		}

		if($_FILES['image4']['name']!='') {	
		$file_4 = $_FILES['image4']['name'];
		$uploadfile_4 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_4 );
		move_uploaded_file( $_FILES['image4']['tmp_name'], $uploadfile_4);
		$filename_4 = basename( $uploadfile_4 );
		$filePath_4 = $uploaddir['baseurl'].'/crew_photos/'.$file_4;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filePath_4), null );
		}

		if($_FILES['image5']['name']!='') {	
		$file_5 = $_FILES['image5']['name'];
		$uploadfile_5 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_5 );
		move_uploaded_file( $_FILES['image5']['tmp_name'], $uploadfile_5);
		$filename_5 = basename( $uploadfile_5 );
		$filePath_5 = $uploaddir['baseurl'].'/crew_photos/'.$file_5;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filePath_5), null );
		}

		if($_FILES['image6']['name']!='') {	
		$file_6 = $_FILES['image6']['name'];
		$uploadfile_6 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_6 );
		move_uploaded_file( $_FILES['image6']['tmp_name'], $uploadfile_6);
		$filename_6 = basename( $uploadfile_6 );
		$filePath_6 = $uploaddir['baseurl'].'/crew_photos/'.$file_6;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filePath_6), null );
		}

		if($_FILES['image7']['name']!='') {	
		$file_7 = $_FILES['image7']['name'];
		$uploadfile_7 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_7 );
		move_uploaded_file( $_FILES['image7']['tmp_name'], $uploadfile_7);
		$filename_7 = basename( $uploadfile_7 );
		$filePath_7 = $uploaddir['baseurl'].'/crew_photos/'.$file_7;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filePath_7), null );
		}

		if($_FILES['image8']['name']!='') {	
		$file_8 = $_FILES['image8']['name'];
		$uploadfile_8 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_8 );
		move_uploaded_file( $_FILES['image8']['tmp_name'], $uploadfile_8);
		$filename_8 = basename( $uploadfile_8 );
		$filePath_8 = $uploaddir['baseurl'].'/crew_photos/'.$file_8;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filePath_8), null );
		}

		if($_FILES['image9']['name']!='') {	
		$file_9 = $_FILES['image9']['name'];
		$uploadfile_9 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_9 );
		move_uploaded_file( $_FILES['image9']['tmp_name'], $uploadfile_9);
		$filename_9 = basename( $uploadfile_9 );
		$filePath_9 = $uploaddir['baseurl'].'/crew_photos/'.$file_9;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filePath_9), null );
		}

		if($_FILES['image10']['name']!='') {	
		$file_10 = $_FILES['image10']['name'];
		$uploadfile_10 = $uploaddir['basedir'] . '/crew_photos/' . basename( $file_10 );
		move_uploaded_file( $_FILES['image10']['tmp_name'], $uploadfile_10);
		$filename_10 = basename( $uploadfile_10 );
		$filePath_10 = $uploaddir['baseurl'].'/crew_photos/'.$file_10;
		//echo "<pre>";print_r($filePath_1);die();	
		$wp_filetype = wp_check_filetype(basename($filePath_10), null );
		}
		
	$home_url = site_url('view-crew-profile').'/'.'?profileid='.$user_profile_url;
		
	$data =$wpdb->query("INSERT INTO wp_crew_apply_form 
  ( fname,
	lname,
	user_profile_url, 
	profile_url, 
	email,
	mobile, 
	gender, 
	city,
	country, 
	citizenship, 
	profile_pic, 
	profession, 
	profession_other_description, 
	gear_list, 
	years_of_experience, 
	sports_experience, 
	video1, 
	video2, 
	video3,
	image1, 
	image2, 
	image3, 
	image4, 
	image5,
	image6,
	image7, 
	image8,
	image9,
	image10,
	website,
	instagram ) 
	VALUES ('".$_POST['fname']."',
	'".$_POST['lname']."' ,
	'".$user_profile_url."',
	'".$home_url."', 
	'".$_POST['email']."', 
	'".$_POST['mobile']."', 
	'".$_POST['gender']."', 
	'".$_POST['city']."', 
	'".$_POST['country']."', 
	'".$_POST['citizenship']."',
	'".$filePath."',
	'".$_POST['profession']."', 
	'".$_POST['profession_other_description']."', 
	'".$_POST['gear_list']."', 
	'".$_POST['years_of_experience']."', 
	'".$_POST['sports_experience']."', 
	'".$_POST['video1']."', 
	'".$_POST['video2']."', 
	'".$_POST['video3']."', 
	'".$filePath_1."', 
	'".$filePath_2."', 
	'".$filePath_3."', 
	'".$filePath_4."', 
	'".$filePath_5."',
	'".$filePath_6."', 
	'".$filePath_7."', 
	'".$filePath_8."', 
	'".$filePath_9."', 
	'".$filePath_10."',  
	'".$_POST['website_url']."',
	'".$_POST['instagram_url']."')"
	 );	 
}  
else { 	
 ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> 
<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>


<form id='apply' class="upload-form custom-form" name="apply" action="" enctype="multipart/form-data" method='POST' onsubmit="return validateform()">
  <fieldset>
  	<h1>CREW PROFILE</h1>
		<div class="top-section">
			<input type="text" name="fname" icon="account_circle" class="" id="input_fname" placeholder="First Name" /> 
			<input type='text' name='lname' icon="account_circle" class="" id="input_0" placeholder="Last Name" />
			<input type="email" name="email" icon="email" class="validate" id="email" placeholder="Email">
			<input type="email" name="cemail" icon="email" class="validate" id="cemail" onblur="confirmEmail()"  placeholder="Confirm Email">
			<input type="tel" name="mobile" icon="stay_primary_portrait" class="validate" id="mobile" placeholder="Mobile number" >
			<input type="text" name="city" icon="business" class="" id="input_8" placeholder="City">
			<input type="text" name="country" class="" id="input_9" placeholder="Country">
			<input type="text" name="citizenship" class="" id="input_11" placeholder="Citizenship">
			<div class="select-div">
				<select id="gender" name="gender" class="input">
					<option value="">Select Gender</option>
					<option value="male">Male</option>
					<option value="female">Female</option>
				</select>
			</div>
		</div>
	  
		<div class="second-section">
			<div class="headings">
				<span class="card-title grey-text text-darken-4">Your Profile</span>
					<p>Maximum file size: 5mb</p>
				<span class="announce">
					<b>IMPORTANT:</b>Please make sure your face is displayed in the <b>center</b> on the image.
				</span>
	  		</div>
			<div class="full-wrapper-content">				
				<span id="profile_pic_pre"></span>			
				<input type="file" id="upload" name="profile_pic" >
				<label for="upload">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
						<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"/>
					</svg>
					<span> Upload headshot&hellip;</span>
				</label>			
			</div>				
		</div>

<div class="entry-content">
	<div class="skill_sec">
		<div class="skills">
		<span class="title">Profession</span>
			<div class="box-input">
				<select id="profession" name="profession" onchange="yesnoCheck()">
					<option value="">Select Profession</option>
					<option value="Director">Director</option>
					<option value="Assistant director">Assistant director</option>
					<option value="Video grapher">Video grapher</option>
					<option value="Photographer">Photographer</option>
					<option value="Producer">Producer</option>
					<option value="editor">editor</option>
					<option value="post production">post production</option>
					<option value="sound tech">sound tech</option>
					<option value="lighting">lighting</option>
					<option value="focus puller">focus puller</option>
					<option value="gaffer">gaffer</option>
					<option value="grade">grade</option>
					<option value="grips">grips</option>
					<option value="rigger">rigger</option>
					<option value="VFX">VFX</option>
					<option value="BTS">BTS</option>
					<option value="wardrobe">wardrobe</option>
					<option value="stylist">stylist</option>
					<option value="hair and make-up">hair and make-up</option>
					<option value="runner">runner</option>
					<option value="catering">catering</option>
					<option value="transport">transport</option>
					<option value="other" id="other">Other</option>
				</select>
			</div>
			<div class="full-wrapper" style="display: none" id="other_description">
				<label for='profession_other_description'>Other</label>
				<textarea id="profession_other_description" name="profession_other_description" class="materialize-textarea undefined "></textarea>
			</div>
			<div class="full-wrapper">
			<label for='gear-list'>Gear List or Description</label>
				<textarea id="gear_list" name="gear_list" class="materialize-textarea undefined "></textarea>
			</div>
			<div class="full-wrapper">
				<select id="years_of_experience" name="years_of_experience">
					<option value="">Years of Experience</option>
					<option value="5+">5+</option>
					<option value="10+">10+</option>
					<option value="15+">15+</option>
					<option value="20+">20+</option>
				</select>
			</div>
		</div>		
	</div>
</div>
	
<div class="entry-content">
	<div class="skill_sec">
		<div class="skills">
			<span class="title">Sports Experience</span>
			<div class="sec_measurements_1">
					<label for='sports_experience' >Have you worked on any sports projects or campaigns?</label>
				<div class="full-wrapper">
					<select id="sports_experience" name="sports_experience">
						<option value="yes">Yes</option>
						<option value="no">No</option>
					</select>
				</div>			
			</div>			
		</div>	
	</div>
</div>

<div class="videos_sec">
	<div class="videos">
		<span class="title">Add up to 3 Videos of your work (Youtube or Vimeo)</span>
		<div class="video_1">
			<div class="box-input">
					<input type="text" name="video1" icon="video_library" class="" id="input_26" placeholder="Video url">
			</div>
			<div class="box-input">
					<input type="text" name="video2" icon="video_library" class="" id="input_26" placeholder="Video url">
			</div>
			<div class="box-input">
					<input type="text" name="video3" icon="video_library" class="" id="input_26" placeholder="Video url">
			</div>					
		</div>
	</div>
</div>

<div class="videos_sec">
	<div class="videos">
		<div class="headings">
			<span class="card-title">Images/Stills</span>
			<p>Maximum file size per image: 5mb</p>
			<span class="announce">Please add up to<b> 10 images</b></span>
		</div>
		<div class="images">
			<div class="top-5-images">
				<div class="box-input">		
					<span id="image11_pre"></span>					
					<input type="file" name="image1" icon="video_library" class="show_image" id="image11" >
					<label for="image11">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
							<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
						</svg>
							<span> Choose Image</span>
					</label>
				</div>
				<div class="box-input">		
					<span id="image2_pre"></span>					
						<input type="file" name="image2" icon="video_library" class="show_image" id="image2">
					<label for="image2">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
							<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
						</svg>
						<span> Choose Image</span>
					</label>
				</div>
				<div class="box-input">		
					<span id="image3_pre"></span>					
						<input type="file" name="image3" icon="video_library" class="show_image" id="image3">
					<label for="image3">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
							<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
						</svg>
						<span> Choose Image</span>
					</label>
				</div>
				<div class="box-input">		
						<span id="image4_pre"></span>
						<input type="file" name="image4" icon="video_library" class="show_image" id="image4">
					<label for="image4">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
							<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
						</svg>
						<span> Choose Image</span>
					</label>
				</div>
			<div class="box-input">		
					<span id="image5_pre"></span>
					<input type="file" name="image5" icon="video_library" class="show_image" id="image5">	
				<label for="image5">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
						<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
					</svg>
					<span> Choose Image</span>
				 </label>
			</div>
			</div>
			<div class="top-5-images">
				<div class="box-input">		
						<span id="image6_pre"></span>
						<input type="file" name="image6" icon="video_library" class="show_image" id="image6">	
					<label for="image6">
						<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
							<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
						</svg>
						<span> Choose Image</span>
					 </label>
				</div>
			<div class="box-input">		
					<span id="image7_pre"></span>
					<input type="file" name="image7" icon="video_library" class="show_image" id="image7">	
				<label for="image7">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
						<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
					</svg>
					<span> Choose Image</span>
				 </label>
			</div>
			<div class="box-input">		
					<span id="image8_pre"></span>
					<input type="file" name="image8" icon="video_library" class="show_image" id="image8">	
				<label for="image8">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
						<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
					</svg>
					<span> Choose Image</span>
				 </label>
			</div>
			<div class="box-input">		
					<span id="image9_pre"></span>
					<input type="file" name="image9" icon="video_library" class="show_image" id="image9">	
				<label for="image9">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
						<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
					</svg>
					<span> Choose Image</span>
				 </label>
			</div>
			<div class="box-input">		
					<span id="image10_pre"></span>
					<input type="file" name="image10" icon="video_library" class="show_image" id="image10">	
				<label for="image10">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17">
						<path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
					</svg>
					<span> Choose Image</span>
				 </label>
			</div>
		</div>
	</div>
</div>
</div>	

	<div class="videos_sec">
		<div class="videos">
			<span class="title">Website and Social Media</span>
			<div class="social">
				<div class="box-input">	
					<input type="text" name="website_url" class="" id="input_29" placeholder="Website Url">
				</div>	
				<div class="box-input">
					<input type="text" name="instagram_url" class="" id="input_31" placeholder="Instagram Url">
				</div>
			</div>
		</div>
	</div>

	<div class="g-recaptcha" data-sitekey="6LeAI0IjAAAAANtaWLsryORynBS2JdZLRMhS6PGY"></div>
		<div class="submit-button">
	    	<input id="apply_forms" name='applyform' type="submit" value="Submit">
		</div>
  </fieldset>
 </form>
  <p class="disclaimer">All information that is stored with Sport & Motion is under strict GDPR regulations and is not made available to the public. Full terms and conditions shall be emailed upon completion. </p>

<?php } ?>