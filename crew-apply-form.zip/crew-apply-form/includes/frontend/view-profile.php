<?php
$admin_email = get_option( 'admin_email' );
global $wpdb;
$user_profile_url=  $_GET['user_profile_url'];
$result = $wpdb->get_row("SELECT * FROM wp_crew_apply_form WHERE user_profile_url = '".$_GET['profileid']."'" );
    
if ($_GET['profileid']!='') {
?>
<div class="logo" style="text-align:center">
	<a href="javascript:;">
		<img src="https://sportandmotion.com/wp-content/uploads/2022/10/SM-Logo-copy.jpg" alt="logo1">
	</a>
</div>
<form id='apply' class="upload-form custom-form">
  <fieldset>
  	<h1>CREW PROFILE</h1>  
		<div class="second-section">
			<div class="headings">
				<span class="card-title grey-text text-darken-4">Features</span>
			</div>
			<div class="left-content">
				<div class="full-wrapper-content">
					<figure>
						<a rel="gallery" class="fancybox" href="<?php echo $result->profile_pic; ?>">
							<img src="<?php echo $result->profile_pic; ?>" />
						</a>
					</figure>
				</div>
				<div class="box-input2">	
					<h4><?php echo $result->fname;?> <?php echo $result->lname; ?><span> (<?php echo $result->citizenship; ?>,  <?php echo $result->gender; ?>)</span></h4>
				</div>
				<div class="box-input2">	
					<span><?php echo $result->city; ?>, <?php echo $result->country; ?></span>
				</div>
			</div>
		</div>	

	<div class="measurements_sec">
	<span class="title">Profession</span>
		<div class="skill_sec">
			<div class="box-input3">
				<?php  
				$display_profession = $result->profession;
					if($display_profession == "other"){
						$display_profession = $result->profession_other_description;
					}
				?>			
				<span><?php echo $display_profession; ?></span>
			</div>
		</div>
		<div class="skill_sec">
			<span class="title">Gear list or description</span>
			<div class="box-input3">
				<span><?php echo $result->gear_list; ?></span>
			</div>		
		</div>
		<div class="skill_sec">
			<span class="title">Years of Experience</span>
			<div class="box-input3">
				<span><?php echo $result->years_of_experience; ?></span>
			</div>		
		</div>
	</div>

	<div class="videos_sec">
		<div class="videos">
			<span class="title">Videos</span>
			<div class="video_1">
				<div class="box-input">
					<label for="video1"><span>Video 1</span></label>
					<?php
						$contains = str_contains($result->video1,'youtu');
						if($contains){
						$arr_1 = explode('?v=', $result->video1);
						if(!isset($arr_1[1])){
						$arr_1 = explode('.be/', $result->video1);
						}
						$video_id_1 = $arr_1[1];
					?>
					<iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $video_id_1; ?>" frameborder="0" allowfullscreen></iframe>					
					<?php }
						else{ 
						$arr_1 = explode('video/', $result->video1);
						if(!isset($arr_1[1])){
						$arr_1 = explode('vimeo.com/', $result->video1);
						}	
						$video_id_1 = $arr_1[1];			
					?>
					<iframe width="100%" height="200" src="https://player.vimeo.com/video/<?php echo $video_id_1; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen=""></iframe>
					<?php } ?>
				</div>

				<div class="box-input">
					<label for="video2"><span>Video 2</span></label>
					<?php
						$contains = str_contains($result->video2,'youtu');
						if($contains){
						$arr_2 = explode('?v=', $result->video2);
						if(!isset($arr_2[1])){
						$arr_2 = explode('.be/', $result->video2);
						}
						$video_id_2 = $arr_2[1];
					?>
					<iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $video_id_2; ?>" frameborder="0" allowfullscreen></iframe>
					<?php }
						else{
						$arr_2 = explode('video/', $result->video2);
						if(!isset($arr_2[1])){
						$arr_2 = explode('vimeo.com/', $result->video1);
						}
						$video_id_2 = $arr_2[1]; 
					?>
					<iframe width="100%" height="200" src="https://player.vimeo.com/video/<?php echo $video_id_2; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen=""></iframe>
					<?php } ?>
				</div>

				<div class="box-input">
					<label for="video3"><span>Video 3</span></label>
					<?php
						$contains = str_contains($result->video3,'youtu');
						if($contains){
						$arr_3 = explode('?v=', $result->video3);
						if(!isset($arr_3[1])){
						$arr_3 = explode('.be/', $result->video3);
						}
						$video_id_3 = $arr_3[1];
					?>
					<iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $video_id_3; ?>" frameborder="0" allowfullscreen></iframe>
					<?php }
						else{
						$arr_3 = explode('video/', $result->video3);
						if(!isset($arr_3[1])){
						$arr_3 = explode('vimeo.com/', $result->video3);
						}
						$video_id_3 = $arr_3[1]; 
					?>
					<iframe width="100%" height="200" src="https://player.vimeo.com/video/<?php echo $video_id_3; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen=""></iframe>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>	

	<div class="images_sec">
		<div class="images">
			<div class="headings">
				<span class="card-title">Images/Stills</span>
			</div>

		<div class="images_container">
			<div class="box-input">				
				<label for="image1"><span>Image 1</span></label>
				<a rel="gallery" class="fancybox" href="<?php echo $result->image1; ?>">
				<img src="<?php echo $result->image1; ?>"></a>
			</div>
			<div class="box-input">
				<span id="image2_pre"></span>
				<label for="image2"><span>Image 2</span></label>
					<a rel="gallery" class="fancybox" href="<?php echo $result->image2; ?>"><img src="<?php echo $result->image2; ?>"></a>
			</div>

			<div class="box-input">		
				<label for="image3"><span>Image 3</span></label>
				<a rel="gallery" class="fancybox" href="<?php echo $result->image3; ?>"><img src="<?php echo $result->image3; ?>"></a>
			</div>
			<div class="box-input">		
				<label for="image4"><span>Image 4</span></label>
					<a rel="gallery" class="fancybox" href="<?php echo $result->image4; ?>">
					<img src="<?php echo $result->image4; ?>"></a>
				</label>
			</div>
			<div class="box-input">		
				<label for="image5"><span>Image 5</span></label>
					<a rel="gallery" class="fancybox" href="<?php echo $result->image5; ?>">
						<img src="<?php echo $result->image5; ?>">
					</a>
			</div>
			<div class="box-input">		
				<label for="image5"><span>Image 6</span></label>
					<a rel="gallery" class="fancybox" href="<?php echo $result->image6; ?>">
						<img src="<?php echo $result->image6; ?>">
					</a>
			</div>
			<div class="box-input">		
				<label for="image5"><span>Image 7</span></label>
					<a rel="gallery" class="fancybox" href="<?php echo $result->image7; ?>">
						<img src="<?php echo $result->image7; ?>">
					</a>
			</div>
			<div class="box-input">		
				<label for="image5"><span>Image 8</span></label>
					<a rel="gallery" class="fancybox" href="<?php echo $result->image8; ?>">
						<img src="<?php echo $result->image8; ?>">
					</a>
			</div>
			<div class="box-input">		
				<label for="image5"><span>Image 9</span></label>
					<a rel="gallery" class="fancybox" href="<?php echo $result->image9; ?>">
						<img src="<?php echo $result->image9; ?>">
					</a>
			</div>
			<div class="box-input">		
				<label for="image5"><span>Image 10</span></label>
					<a rel="gallery" class="fancybox" href="<?php echo $result->image10; ?>">
						<img src="<?php echo $result->image10; ?>">
					</a>
			</div>
		</div>
	</div>
</div>	

	<div class="content_sec">
		<div class="content-box">
			<span class="title">Content</span>
			<div class="social">
				<?php  
				if ($result->website) {  ?>
				<div class="box-input">	
					<label for="website"><span><a href="<?php echo $result->website; ?>" target="_blank">Website</a></span></label>
				</div>					
				<?php }
				else{ ?>
				<div class="box-input">	
					<label for="website"><span>Website</span></label>
					</div>	
				<?php }

				if ($result->instagram) {  ?>
				<div class="box-input">				
					<label for="instagram"><span><a href="<?php echo $result->instagram; ?>" target="_blank">Instagram</a></span></label>
				</div>
				<?php }
				else {  ?>
				<div class="box-input">
					<label for="instagram"><span>Instagram</span></label>
				</div>
				<?php } ?>	
			</div>
		</div>
	</div>
  </fieldset>
</form>
<?php } else { ?>
<script type="text/javascript">
	window.location = '<?php echo site_url(); ?>';
</script>
<?php } ?>