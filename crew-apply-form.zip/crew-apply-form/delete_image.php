<?php


require_once('../../../wp-config.php');
require_once('../../../wp-load.php');

$user_id= $_POST['id']; 
$img_flag=$_POST['imageflag'];
//echo $user_id;

global $wpdb;
 $sql="UPDATE wp_apply_form SET $img_flag=' ' WHERE id='$user_id'";
 $result_1 = $wpdb->query( $sql);
 
 exit;

?>