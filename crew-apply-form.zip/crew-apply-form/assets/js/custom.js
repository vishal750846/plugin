function confirmEmail() {
    var email = document.getElementById("email").value
    var confemail = document.getElementById("cemail").value
    if(email != confemail) {
    alert('Email Not Matching!');
    return false;  
    }
}

function yesnoCheck() { 
    if (document.getElementById("other").selected) {
       document.getElementById("other_description").style.display = "block";
   } else { 
   document.getElementById("other_description").style.display = "none";
   }
}

function validateform(){

    var fname=document.apply.fname.value;  
    if (fname==null || fname==""){  
    alert("First Name can't be blank");  
    return false;  
    }	

    var lname=document.apply.lname.value;  
    if (lname==null || lname==""){  
    alert("Last Name can't be blank");  
    return false;  
    }

    var email=document.apply.email.value;  
    if (email==null || email==""){  
    alert("Email can't be blank");  
    return false;  
    }

    var cemail=document.apply.cemail.value;  
    if (cemail==null || cemail==""){  
    alert("Confirm Email can't be blank");  
    return false;  
    }

    var gender=document.apply.gender.value;  
    if (gender==null || gender==""){  
    alert("Please Select Gender");  
    return false;  
    }

    var city=document.apply.city.value;  
    if (city==null || city==""){  
    alert("City can't be blank");  
    return false;  
    }

    var country=document.apply.country.value;  
    if (country==null || country==""){  
    alert("Country can't be blank");  
    return false;  
    }

    var citizenship=document.apply.citizenship.value;  
    if (citizenship==null || citizenship==""){  
    alert("Citizen Ship can't be blank");  
    return false;  
    }

    var profile_pic=document.apply.profile_pic.value;  
    if (profile_pic==null || profile_pic==""){  
    alert("Profile Pic can't be blank");  
    return false;  
    }

    var profession=document.apply.profession.value;  
    if (profession==null || profession==""){  
    alert("Please Select Profession");  
    return false;  
    }

    var gear_list=document.apply.gear_list.value;  
    if (gear_list==null || gear_list==""){  
    alert("GEAR LIST OR DESCRIPTION can't be blank");  
    return false;  
    }

    var years_of_experience=document.apply.years_of_experience.value;  

    if (years_of_experience==null || years_of_experience==""){  
    alert("Please Select Years of Experience");  
    return false;  
    }

    var sports_experience=document.apply.sports_experience.value;  

    if (sports_experience==null || sports_experience==""){  
    alert("Please Select Sports Experience");  
    return false;  
    }

    var video1=document.apply.video1.value;  
    if (video1==null || video1==""){  
    alert("Video can't be blank");  
    return false;  
    }

    var video2=document.apply.video2.value;  
    if (video2==null || video2==""){  
    alert("Video can't be blank");  
    return false;  
    }

    var video3=document.apply.video3.value;  
    if (video3==null || video3==""){  
    alert("Video can't be blank");  
    return false;  
    }

    var image1=document.apply.image1.value;  
    if (image1==null || image1==""){  
    alert("Image can't be blank");  
    return false;  
    }

    var image2=document.apply.image2.value;  
    if (image2==null || image2==""){  
    alert("Image can't be blank");  
    return false;  
    }

    var image3=document.apply.image3.value;  
    if (image3==null || image3==""){  
    alert("Image can't be blank");  
    return false;  
    }

    var image4=document.apply.image4.value;  
    if (image4==null || image4==""){  
    alert("Image can't be blank");  
    return false;  
    }

    var image5=document.apply.image5.value;  
    if (image5==null || image5==""){  
    alert("Image can't be blank");  
    return false;  
    }

    var image6=document.apply.image6.value;  
    if (image6==null || image6==""){  
    alert("Image can't be blank");  
    return false;  
    }

    var image7=document.apply.image7.value;  
    if (image7==null || image7==""){  
    alert("Image can't be blank");  
    return false;  
    }

    var image8=document.apply.image8.value;  
    if (image8==null || image8==""){  
    alert("Image can't be blank");  
    return false;  
    }

    var image9=document.apply.image9.value;  
    if (image9==null || image9==""){  
    alert("Image can't be blank");  
    return false;  
    }

    var image10=document.apply.image10.value;  
    if (image10==null || image10==""){  
    alert("Image can't be blank");  
    return false;  
    }

    // var response = grecaptcha.getResponse();
    // if(response.length == 0){
    // alert("please verify reCaptcha!"); 
    // return false;
    // }

    var website_url=document.apply.website_url.value;  
    if (website_url==null || website_url==""){  
    alert("Website Url can't be blank");  
    return false;  
    }

    var instagram_url=document.apply.instagram_url.value;  
    if (instagram_url==null || instagram_url==""){  
    alert("Instagram Url can't be blank");  
    return false;  
    }

    var mobile = document.getElementById("mobile").value;
    var pattern = /^\d{10}$/;
    if (pattern.test(mobile)) {
        alert("Your mobile number : " + mobile);
        return true;
    }
    else{
        alert("It is not valid mobile number.input 10 digits number!");
        return false;
    }

}

jQuery(function () {
jQuery("#upload").change(function () {
   jQuery("#profile_pic_pre").html("");
   var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
   if (regex.test(jQuery(this).val().toLowerCase())) {
       if (jQuery.browser.msie && parseFloat(jQuery.browser.version) <= 9.0) {
           jQuery("#profile_pic_pre").show();
           jQuery("#profile_pic_pre")[0].filters.item("DXImageTransform.Microsoft.AlphaImageLoader").src = jQuery(this).val();
       }
       else {
           if (typeof (FileReader) != "undefined") {
               jQuery("#profile_pic_pre").show();
               jQuery("#profile_pic_pre").append("<img />");
               var reader = new FileReader();
               reader.onload = function (e) {
                   jQuery("#profile_pic_pre img").attr("src", e.target.result);
               }
               reader.readAsDataURL(jQuery(this)[0].files[0]);
           } else {
               alert("This browser does not support FileReader.");
           }
       }
   } else {
       alert("Please upload a valid image file.");
   }
});
});


jQuery(function () {
jQuery(".show_image").change(function () {
   let id = jQuery(this).attr('id');
   jQuery(`#${id}_pre`).html("");
   var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
   if (regex.test(jQuery(this).val().toLowerCase())) {
       if (jQuery.browser.msie && parseFloat(jQuery.browser.version) <= 9.0) {
           jQuery(`#${id}_pre`).show();
           jQuery(`#${id}_pre`)[0].filters.item("DXImageTransform.Microsoft.AlphaImageLoader").src = jQuery(this).val();
       }
       else {
           if (typeof (FileReader) != "undefined") {
               jQuery(`#${id}_pre`).show();
               jQuery(`#${id}_pre`).append("<img />");
               var reader = new FileReader();
               reader.onload = function (e) {
                   jQuery(`#${id}_pre img`).attr("src", e.target.result);
               }
               reader.readAsDataURL(jQuery(this)[0].files[0]);
           } else {
               alert("This browser does not support FileReader.");
           }
       }
   } else {
       alert("Please upload a valid image file.");
   }
});
});

jQuery( document ).ready(function() {
    jQuery(".fancybox")
        .attr('rel', 'gallery')
        .fancybox({
            openEffect  : 'none',
            closeEffect : 'none',
            nextEffect  : 'none',
            prevEffect  : 'none',
            padding     : 0,
            margin      : [20, 60, 20, 60] // Increase left/right margin
        });
});